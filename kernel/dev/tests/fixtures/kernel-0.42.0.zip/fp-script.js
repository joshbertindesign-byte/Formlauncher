/* Form Platform: the script, a definition written as text (step 25, part 3).
 * Load after fp-form-editor.js (the editor) or after fp-defs.js (tests).
 *
 * The script is the platform's own text notation for a definition, not a programming language. It is a
 * second view of the same JSON the visual editors edit, and converts both ways without loss:
 *
 *   form od-check "OD check"
 *     sites all
 *
 *     source odCheck item
 *       structure od-checks
 *       id new OD
 *
 *     field measuredOD number "Measured OD" required
 *       unit in
 *       saves odCheck.measuredOD
 *     field result value "Result"
 *       = InSpec(measuredOD, spec.min, spec.max)
 *
 *     layout
 *       row measuredOD 6  result 6
 *
 *     button save "Save"
 *       save tree
 *
 * One line, one statement, keyword first; what belongs to a line sits indented under it. Text with spaces
 * goes in "quotes"; a formula starts with = and runs to the end of the line; # starts a comment (kept, by
 * line, in the definition's comments). yes and no are true and false, none is nothing. Defaults are never
 * written. A setting the notation has no special line for is written as its name and value, so anything
 * the visual editor can set can be written, and nothing else: there are no variables, loops or includes.
 *
 * FP.script.write(kind, id, def) -> text          tidy: one standard order and spacing
 * FP.script.read(text) -> { kind, id, def, problems: [{ line, text }], lineOf(path), paths }
 * FP.script.lineFor(read, message) -> line         where a check's message belongs
 * FP.script.complete(text, line, col) -> { from, items }   what can come next at the cursor
 */
(function () {
  'use strict';

  const FP = window.FP;
  if (!FP || !FP.defs) throw new Error('Load fp-defs.js before fp-script.js');

  const KINDS = ['form', 'structure', 'function', 'session-type', 'field', 'group'];
  const TITLE_KEY = { form: 'title' };   // others: label
  const RESERVED = new Set(['yes', 'no', 'none', 'list', 'item', 'json']);
  const NUM_RE = /^-?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/;
  const FORMULA_KEYS = new Set(['formula', 'when', 'optionsFrom', 'filter', 'where', 'open', 'caption', 'tone']);
  const FORMULA_MAPS = new Set(['prefill', 'where']);   // where: a single formula (an item found by a rule), or tag = formula (media)
  // Keys whose value is a list of words, written without the word list: sites all, options L01 L02.
  const LIST_KEYS = new Set(['sites', 'options', 'signatures', 'stamp', 'roles', 'actions']);
  // Glossary names in the script for the JSON's own names.
  const ALIAS_OUT = { writes: 'saves', output: 'gives' };
  const ALIAS_IN = { saves: 'writes', gives: 'output' };
  // Settings whose value is one word from a fixed set, which may be list or item: written bare (gives list).
  const VALUE_KEYS = new Set(['output', 'summary', 'type', 'kind', 'rule', 'from', 'made', 'show', 'every', 'fold', 'action', 'control', 'style', 'mode']);
  const TYPES = ['text', 'number', 'date', 'boolean', 'list', 'record', 'item', 'any'];
  const CELL_WIDTH = /^(\d+|[A-Za-z]+:\d+)$/;

  /* The closest word in a list, for "did you mean": at most two letters off, capitals aside. */
  function near(word, list) {
    const w = String(word || '').toLowerCase();
    let best = null, bd = 3;
    (list || []).forEach(x => {
      const a = String(x).toLowerCase();
      if (Math.abs(a.length - w.length) > 2) return;
      const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
      for (let j = 1; j <= w.length; j++) d[0][j] = j;
      for (let i = 1; i <= a.length; i++) for (let j = 1; j <= w.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === w[j - 1] ? 0 : 1));
      const dist = d[a.length][w.length];
      if (dist < bd) { bd = dist; best = x; }
    });
    return best;
  }
  const mean = (word, list) => { const n = near(word, list); return n ? ` Did you mean ${n}?` : ''; };

  /* ---------- Writing values ---------- */
  const bareOk = s => /^[^\s"#=][^\s"]*$/.test(s) && !RESERVED.has(s.toLowerCase()) && !NUM_RE.test(s);
  const quote = s => '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
  function tok(v) {
    if (v === true) return 'yes';
    if (v === false) return 'no';
    if (v == null) return 'none';
    if (typeof v === 'number') { const s = String(v); return NUM_RE.test(s) && Number(s) === v ? s : quote(s); }
    const s = String(v);
    return bareOk(s) ? s : quote(s);
  }
  const keyTok = k => (bareOk(k) ? k : quote(k));
  const formulaOk = v => typeof v === 'string' && v !== '' && v === v.trim() && !/[\n\r]/.test(v);
  const fx = v => (formulaOk(v) ? '= ' + v : tok(v));
  const scalar = v => v == null || typeof v !== 'object';
  const plainObj = v => v != null && typeof v === 'object' && !Array.isArray(v);

  /* ---------- Reading a line ---------- */
  // tokens: { t: 'word' | 'text' | 'formula', v, at }
  function lex(raw) {
    const out = { tokens: [], comment: null, error: null };
    let i = 0;
    const s = raw;
    while (i < s.length) {
      while (i < s.length && /\s/.test(s[i])) i++;
      if (i >= s.length) break;
      const ch = s[i];
      if (ch === '#') { out.comment = s.slice(i + 1).trim(); break; }
      if (ch === '=') { out.tokens.push({ t: 'formula', v: s.slice(i + 1).trim(), at: i }); break; }
      if (ch === '"') {
        let j = i + 1, v = '';
        while (j < s.length && s[j] !== '"') {
          if (s[j] === '\\' && j + 1 < s.length) { const n = s[j + 1]; v += n === 'n' ? '\n' : n === 't' ? '\t' : n; j += 2; } else v += s[j++];
        }
        if (j >= s.length) { out.error = { at: i, text: 'A piece of text is missing its closing "' }; out.tokens.push({ t: 'text', v, at: i }); break; }
        out.tokens.push({ t: 'text', v, at: i });
        i = j + 1;
        continue;
      }
      let j = i;
      while (j < s.length && !/\s/.test(s[j])) j++;
      out.tokens.push({ t: 'word', v: s.slice(i, j), at: i });
      i = j;
    }
    return out;
  }
  const val = tk => {
    if (!tk) return null;
    if (tk.t !== 'word') return tk.v;
    const w = tk.v, l = w.toLowerCase();
    if (l === 'yes') return true;
    if (l === 'no') return false;
    if (l === 'none') return null;
    if (NUM_RE.test(w)) return Number(w);
    return w;
  };
  const isWord = (tk, w) => tk && tk.t === 'word' && tk.v.toLowerCase() === w;
  const str = tk => (tk ? String(tk.v) : '');

  /* The lines as a tree by indentation. Comment lines go with the statement after them. */
  function parse(text) {
    const lines = String(text || '').replace(/\r\n?/g, '\n').split('\n');
    const problems = [];
    const root = { indent: -1, children: [], line: 0 };
    const stack = [root];
    let pending = [];
    lines.forEach((raw, k) => {
      const n = k + 1;
      const expanded = raw.replace(/\t/g, '  ');
      const indent = expanded.length - expanded.trimStart().length;
      const body = expanded.trim();
      if (!body) return;
      const lx = lex(expanded.slice(indent));
      if (lx.error) problems.push({ line: n, text: lx.error.text });
      if (!lx.tokens.length) { if (lx.comment != null) pending.push(lx.comment); return; }
      while (stack.length > 1 && stack[stack.length - 1].indent >= indent) stack.pop();
      const parent = stack[stack.length - 1];
      // A line indented less than its siblings but more than their parent: which does it belong to?
      if (parent.children.length) {
        const sib = parent.children[parent.children.length - 1];
        if (indent !== sib.indent && indent < sib.indent) problems.push({ line: n, text: `This line is indented less than line ${sib.line} above it but more than line ${parent.line || 1}: line it up with one of them, so it's clear which it belongs to.` });
      }
      let flagged = !!parent.flagged;
      if (!flagged && parent !== root && indent - parent.indent === 1) { problems.push({ line: n, text: `This line is one space further in than line ${parent.line}: line it up with line ${parent.line}, or indent it two spaces more to put it under line ${parent.line}.` }); flagged = true; }
      const node = { line: n, indent, tokens: lx.tokens, comment: lx.comment, above: pending, children: [], flagged };
      pending = [];
      parent.children.push(node);
      stack.push(node);
    });
    return { root, problems, lines };
  }

  /* Each statement's address, the same from the writer's lines and the reader's: parent / keyword name. */
  const ELEMENT = new Set(['field', 'button', 'source', 'read', 'column', 'input', 'container', 'calculated', 'status', 'tag', 'section', 'tab', 'step', 'match']);
  function addPaths(node, prefix, out) {
    const seen = new Map();
    node.children.forEach(c => {
      const kw = c.tokens[0].t === 'formula' ? '=' : str(c.tokens[0]).toLowerCase();
      let label = kw + (ELEMENT.has(kw) && c.tokens[1] && c.tokens[1].t !== 'formula' ? ' ' + str(c.tokens[1]) : '');
      const k = (seen.get(label) || 0) + 1;
      seen.set(label, k);
      if (k > 1) label += ' ~' + k;
      c.path = prefix ? prefix + ' / ' + label : label;
      out.set(c.path, c);
      addPaths(c, c.path, out);
    });
    return out;
  }

  /* ---------- The writer ---------- */
  function Writer() {
    const lines = [];
    return {
      lines,
      put(ind, text) { lines.push({ ind, text }); },
      blank() { if (lines.length && lines[lines.length - 1].text !== '') lines.push({ ind: 0, text: '' }); },
    };
  }

  // Any value under a key, in the general form: key value | key list a b | key item … | key + lines under it.
  function writeValue(w, ind, key, v, ctx) {
    const k = keyTok(ALIAS_OUT[key] && ctx !== 'raw' ? ALIAS_OUT[key] : key);
    const asFormula = FORMULA_KEYS.has(key) || ctx === 'formulas';
    if (scalar(v)) { w.put(ind, `${k} ${asFormula ? fx(v) : VALUE_KEYS.has(key) && typeof v === 'string' && /^(list|item|json)$/i.test(v) ? v : tok(v)}`); return; }
    if (Array.isArray(v)) {
      if (v.every(scalar)) { w.put(ind, `${k}${LIST_KEYS.has(key) && v.length ? '' : ' list'}${v.map(x => ' ' + tok(x)).join('')}`); return; }
      v.forEach(x => {
        if (scalar(x)) w.put(ind, `${k} item ${tok(x)}`);
        else if (Array.isArray(x)) {
          if (x.every(scalar)) w.put(ind, `${k} item list${x.map(y => ' ' + tok(y)).join('')}`);
          else w.put(ind, `${k} item json ${quote(JSON.stringify(x))}`);
        } else { w.put(ind, `${k} item`); writeObject(w, ind + 1, x); }
      });
      return;
    }
    w.put(ind, k);
    writeObject(w, ind + 1, v, FORMULA_MAPS.has(key) ? 'formulas' : null);
  }
  function writeObject(w, ind, obj, ctx, skip) {
    Object.keys(obj).forEach(key => { if (!(skip && skip.includes(key)) && obj[key] !== undefined) writeValue(w, ind, key, obj[key], ctx); });
  }
  const rest = (obj, used) => Object.keys(obj).filter(k => !used.includes(k) && obj[k] !== undefined);
  function writeRest(w, ind, obj, used) { rest(obj, used).forEach(k => writeValue(w, ind, k, obj[k])); }

  /* Layout rows: row line 4  profile pc:4 tablet:6 */
  function cellsOf(tokens) {
    const cells = [];
    tokens.forEach(t => { const s = String(t); if (CELL_WIDTH.test(s) && cells.length) cells[cells.length - 1] += ' ' + s; else cells.push(s); });
    return cells;
  }
  function rowLine(r) {
    if (!r.every(c => typeof c === 'string')) return null;
    const parts = [];
    r.forEach(c => String(c).trim().split(/\s+/).forEach((p, i) => parts.push({ p, gap: i === 0 && parts.length })));
    const back = cellsOf(parts.map(x => x.p));
    if (JSON.stringify(back) !== JSON.stringify(r.map(c => String(c).trim().split(/\s+/).join(' '))) || parts.some(x => !bareOk(x.p) && !NUM_RE.test(x.p))) return null;
    return 'row' + parts.map(x => (x.gap ? '  ' : ' ') + x.p).join('');
  }
  function writeRows(w, ind, rows) {
    rows.forEach(r => {
      if (Array.isArray(r)) { const l = rowLine(r); w.put(ind, l == null ? `row json ${quote(JSON.stringify(r))}` : l); return; }
      if (plainObj(r) && typeof r.section === 'string') {
        w.put(ind, `section ${tok(r.section)}`);
        writeRest(w, ind + 1, r, ['section', 'rows']);
        if (Array.isArray(r.rows)) { if (r.rows.length) writeRows(w, ind + 1, r.rows); else w.put(ind + 1, 'rows list'); }
        else if (r.rows !== undefined) writeValue(w, ind + 1, 'rows', r.rows);
        return;
      }
      if (plainObj(r) && (Array.isArray(r.tabs) || Array.isArray(r.steps))) {
        const kind = Array.isArray(r.tabs) ? 'tab' : 'step';
        w.put(ind, kind + 's');
        writeRest(w, ind + 1, r, [kind + 's']);
        r[kind + 's'].forEach(t => {
          if (!plainObj(t) || typeof t[kind] !== 'string') { w.put(ind + 1, `${kind} json ${quote(JSON.stringify(t))}`); return; }
          w.put(ind + 1, `${kind} ${tok(t[kind])}`);
          writeRest(w, ind + 2, t, [kind, 'rows']);
          if (Array.isArray(t.rows)) { if (t.rows.length) writeRows(w, ind + 2, t.rows); else w.put(ind + 2, 'rows list'); }
          else if (t.rows !== undefined) writeValue(w, ind + 2, 'rows', t.rows);
        });
        return;
      }
      w.put(ind, `row json ${quote(JSON.stringify(r))}`);
    });
  }
  function writeLayout(w, ind, layout) {
    if (!Array.isArray(layout)) { writeValue(w, ind, 'layout', layout); return; }
    w.put(ind, layout.length ? 'layout' : 'layout list');
    writeRows(w, ind + 1, layout);
  }

  /* ---------- Each kind ---------- */
  function writeForm(w, def, base) {
    base = base || 0;
    const order = ['sites', 'launchable', 'approval', 'action', 'saveLabel', 'savedMessage', 'backLabel', 'nextLabel', 'refresh'];
    order.forEach(k => { if (def[k] !== undefined) writeValue(w, base + 1, k, def[k]); });
    if (def.print !== undefined && !plainObj(def.print)) writeValue(w, base + 1, 'print', def.print);
    if (Array.isArray(def.sources)) {
      def.sources.forEach(s => {
        w.blank();
        if (!plainObj(s) || typeof s.name !== 'string' || typeof s.kind !== 'string') { w.put(base + 1, `source json ${quote(JSON.stringify(s))}`); return; }
        w.put(base + 1, `source ${tok(s.name)} ${['item', 'items', 'value'].includes(s.kind) ? s.kind : tok(s.kind)}${s.kind === 'value' && formulaOk(s.formula) ? ' = ' + s.formula : ''}`);
        const used = ['name', 'kind'].concat(s.kind === 'value' && formulaOk(s.formula) ? ['formula'] : []);
        if (s.structure !== undefined) { writeValue(w, base + 2, 'structure', s.structure); used.push('structure'); }
        const id = s.id;
        if (plainObj(id)) {
          const ks = Object.keys(id).filter(k => id[k] !== undefined).sort().join(',');
          let line = null;
          if (ks === 'field' && typeof id.field === 'string') line = `id field ${tok(id.field)}`;
          else if (ks === 'fixed' && typeof id.fixed === 'string') line = `id fixed ${tok(id.fixed)}`;
          else if (ks === 'generate' && id.generate === true) line = 'id new';
          else if (ks === 'generate,prefix' && id.generate === true && typeof id.prefix === 'string') line = `id new ${tok(id.prefix)}`;
          else if (ks === 'where' && formulaOk(id.where)) line = `id where = ${id.where}`;
          if (line) { w.put(base + 2, line); used.push('id'); }
        }
        writeRest(w, base + 2, s, used);
      });
    } else if (def.sources !== undefined) writeValue(w, base + 1, 'sources', def.sources);
    if (Array.isArray(def.acknowledge)) {
      def.acknowledge.forEach(a => {
        w.blank();
        if (!plainObj(a)) { w.put(base + 1, `read json ${quote(JSON.stringify(a))}`); return; }
        if (typeof a.name === 'string') { w.put(base + 1, `read ${tok(a.name)}`); writeRest(w, base + 2, a, ['name']); }
        else { w.put(base + 1, 'read'); writeObject(w, base + 2, a); }
      });
    } else if (def.acknowledge !== undefined) writeValue(w, base + 1, 'acknowledge', def.acknowledge);
    if (Array.isArray(def.fields)) {
      w.blank();
      def.fields.forEach(f => {
        if (!plainObj(f) || typeof f.name !== 'string' || typeof f.control !== 'string') { w.put(base + 1, `field json ${quote(JSON.stringify(f))}`); return; }
        const label = typeof f.label === 'string' ? ' ' + (f.label === 'required' ? quote(f.label) : tok(f.label)) : '';
        w.put(base + 1, `field ${tok(f.name)} ${tok(f.control)}${label}${f.required === true ? ' required' : ''}`);
        const used = ['name', 'control'].concat(typeof f.label === 'string' ? ['label'] : [], f.required === true ? ['required'] : []);
        if (formulaOk(f.formula)) { w.put(base + 2, '= ' + f.formula); used.push('formula'); }
        if (Array.isArray(f.columns) && f.columns.every(c => plainObj(c) && typeof c.name === 'string')) {
          writeRest(w, base + 2, f, used.concat('columns'));
          f.columns.forEach(c => { w.put(base + 2, `column ${tok(c.name)}`); writeRest(w, base + 3, c, ['name']); });
        } else writeRest(w, base + 2, f, used);
      });
    } else if (def.fields !== undefined) writeValue(w, base + 1, 'fields', def.fields);
    if (def.layout !== undefined) { w.blank(); writeLayout(w, base + 1, def.layout); }
    if (Array.isArray(def.buttons)) {
      w.blank();
      if (!def.buttons.length) w.put(base + 1, 'buttons list');
      def.buttons.forEach(b => {
        if (!plainObj(b) || typeof b.name !== 'string') { w.put(base + 1, `button json ${quote(JSON.stringify(b))}`); return; }
        w.put(base + 1, `button ${tok(b.name)}${typeof b.label === 'string' ? ' ' + tok(b.label) : ''}`);
        const used = ['name'].concat(typeof b.label === 'string' ? ['label'] : []);
        if (b.action === 'save') { w.put(base + 2, `save${typeof b.scope === 'string' ? ' ' + tok(b.scope) : ''}`); used.push('action'); if (typeof b.scope === 'string') used.push('scope'); }
        else if (b.action === 'open' && typeof b.form === 'string') { w.put(base + 2, `open ${tok(b.form)}`); used.push('action', 'form'); }
        else if (b.action === 'subform' && typeof b.subform === 'string') { w.put(base + 2, `subform ${tok(b.subform)}`); used.push('action', 'subform'); }
        writeRest(w, base + 2, b, used);
      });
    } else if (def.buttons !== undefined) writeValue(w, base + 1, 'buttons', def.buttons);
    if (Array.isArray(def.subforms) && !base) {
      def.subforms.forEach(sf => {
        w.blank();
        if (!plainObj(sf) || typeof sf.name !== 'string') { w.put(1, `subform json ${quote(JSON.stringify(sf))}`); return; }
        w.put(1, `subform ${tok(sf.name)}${typeof sf.label === 'string' ? ' ' + tok(sf.label) : ''}`);
        if (formulaOk(sf.title)) w.put(2, `title = ${sf.title}`);
        const rp = sf.repeat;
        let rpDone = false;
        if (plainObj(rp) && Object.keys(rp).length === 1) {
          if (rp.open === true) { w.put(2, 'repeat open'); rpDone = true; }
          else if (typeof rp.count === 'number') { w.put(2, `repeat count ${rp.count}`); rpDone = true; }
          else if (formulaOk(rp.count)) { w.put(2, `repeat count = ${rp.count}`); rpDone = true; }
          else if (formulaOk(rp.list)) { w.put(2, `repeat list = ${rp.list}`); rpDone = true; }
        }
        let backDone = false;
        if (Array.isArray(sf.back) && sf.back.every(x => plainObj(x) && typeof x.to === 'string' && typeof x.from === 'string' && Object.keys(x).every(k => ['to', 'from', 'how'].includes(k)) && (x.how === undefined || typeof x.how === 'string'))) {
          sf.back.forEach(x => w.put(2, `back ${tok(x.to)} ${tok(x.from)}${x.how ? ' ' + tok(x.how) : ''}`));
          backDone = true;
        }
        ['saves', 'required', 'link'].forEach(k => { if (sf[k] !== undefined) writeValue(w, 2, k, sf[k]); });
        const inner = Object.assign({}, sf);
        ['name', 'label', 'saves', 'required', 'link'].forEach(k => delete inner[k]);
        if (formulaOk(sf.title)) delete inner.title;
        if (rpDone) delete inner.repeat;
        if (backDone) delete inner.back;
        writeForm(w, inner, 1);
      });
    } else if (def.subforms !== undefined) writeValue(w, base + 1, 'subforms', def.subforms);
    if (plainObj(def.print)) {
      w.blank();
      w.put(base + 1, 'print');
      writeRest(w, base + 2, def.print, ['layout']);
      if (def.print.layout !== undefined) writeLayout(w, base + 2, def.print.layout);
    }
    // The form's media list: one line per file, its tags under it.
    const mediaOk = Array.isArray(def.media) && def.media.every(m => plainObj(m) && typeof m.path === 'string' && Object.keys(m).every(k => ['path', 'title', 'tags'].includes(k)) && (m.tags === undefined || (plainObj(m.tags) && Object.values(m.tags).every(v => scalar(v) || (Array.isArray(v) && v.every(scalar))))));
    if (mediaOk && def.media.length) {
      w.blank();
      const plainTitle = m => m.path.split('/').pop().replace(/\.[A-Za-z0-9]{1,8}$/, '');
      def.media.forEach(m => {
        w.put(base + 1, `media ${tok(m.path)}${typeof m.title === 'string' && m.title !== plainTitle(m) ? ' ' + tok(m.title) : ''}`);
        Object.entries(m.tags || {}).forEach(([k, v]) => w.put(base + 2, `tag ${tok(k)}${[].concat(v).map(x => ' ' + tok(x)).join('')}`));
      });
    } else if (def.media !== undefined && !(Array.isArray(def.media) && !def.media.length)) writeValue(w, base + 1, 'media', def.media);
    const left = rest(def, order.concat(['title', 'print', 'sources', 'acknowledge', 'fields', 'layout', 'buttons', 'comments', 'subforms', 'media']));
    if (left.length) { w.blank(); left.forEach(k => writeValue(w, base + 1, k, def[k])); }
  }

  function writeStructure(w, def) {
    if (def.sites !== undefined) writeValue(w, 1, 'sites', def.sites);
    const used = ['label', 'sites', 'comments'];
    const t = def.itemId;
    if (t !== undefined) {
      used.push('itemId');
      const okKeys = plainObj(t) && Object.keys(t).every(k => ['label', 'made', 'prefix'].includes(k))
        && (t.made == null || t.made === 'entered' || t.made === 'new') && (t.prefix == null || (t.made === 'new' && typeof t.prefix === 'string'))
        && (t.label == null || typeof t.label === 'string');
      if (okKeys) {
        const label = t.label != null ? ' ' + (['new', 'entered'].includes(String(t.label).toLowerCase()) ? quote(t.label) : tok(t.label)) : '';
        w.put(1, `id${label}${t.made ? ' ' + t.made : ''}${t.prefix ? ' ' + tok(t.prefix) : ''}`);
      } else writeValue(w, 1, 'itemId', t, 'raw');
    }
    if (plainObj(def.live) && Object.keys(def.live).length === 1 && Number.isInteger(def.live.days)) { w.put(1, `live ${def.live.days}`); used.push('live'); }
    if (formulaOk(def.open)) { w.put(1, `open = ${def.open}`); used.push('open'); }
    const rules = (FP.summary && FP.summary.rules) || [];
    if (plainObj(def.containers)) {
      used.push('containers');
      w.blank();
      if (!Object.keys(def.containers).length) w.put(1, 'containers');
      Object.entries(def.containers).forEach(([n, c]) => {
        if (!plainObj(c)) { w.put(1, `container ${keyTok(n)} json ${quote(JSON.stringify(c))}`); return; }
        const r = typeof c.rule === 'string' && rules.includes(c.rule) ? ' ' + c.rule : '';
        const fr = typeof c.from === 'string' ? ` from ${tok(c.from)}` : '';
        w.put(1, `container ${keyTok(n)}${r}${fr}`);
        writeRest(w, 2, c, [].concat(r ? ['rule'] : [], fr ? ['from'] : []));
      });
    }
    if (plainObj(def.calculated)) {
      used.push('calculated');
      w.blank();
      if (!Object.keys(def.calculated).length) w.put(1, 'calculated');
      Object.entries(def.calculated).forEach(([n, c]) => {
        if (plainObj(c) && typeof c.fn === 'string' && Object.keys(c).every(k => k === 'fn' || k === 'inputs') && (c.inputs === undefined || plainObj(c.inputs))) {
          w.put(1, `calculated ${keyTok(n)} ${c.fn ? tok(c.fn) : '""'}${c.inputs === undefined ? ' none' : ''}`);
          Object.entries(c.inputs || {}).forEach(([k, v]) => writeValue(w, 2, k, v));
        } else { w.put(1, `calculated ${keyTok(n)} json ${quote(JSON.stringify(c))}`); }
      });
    }
    if (Array.isArray(def.status)) {
      used.push('status');
      w.blank();
      if (!def.status.length) w.put(1, 'status list');
      def.status.forEach(r => {
        if (!plainObj(r) || typeof r.value !== 'string') { w.put(1, `status json ${quote(JSON.stringify(r))}`); return; }
        w.put(1, `status ${tok(r.value)}${formulaOk(r.when) ? ' = ' + r.when : ''}`);
        writeRest(w, 2, r, ['value'].concat(formulaOk(r.when) ? ['when'] : []));
      });
    }
    const left = rest(def, used);
    if (left.length) { w.blank(); left.forEach(k => writeValue(w, 1, k, def[k])); }
  }

  function writeFunction(w, def) {
    if (def.sites !== undefined) writeValue(w, 1, 'sites', def.sites);
    if (def.kind !== undefined) writeValue(w, 1, 'kind', def.kind);
    const used = ['label', 'sites', 'kind', 'comments'];
    if (Array.isArray(def.inputs)) {
      used.push('inputs');
      if (!def.inputs.length) w.put(1, 'inputs list');
      def.inputs.forEach(inp => {
        if (!plainObj(inp) || typeof inp.name !== 'string') { w.put(1, `input json ${quote(JSON.stringify(inp))}`); return; }
        const ty = TYPES.includes(inp.type) ? ' ' + inp.type : '';
        w.put(1, `input ${tok(inp.name)}${ty}${inp.required === false ? ' optional' : ''}`);
        writeRest(w, 2, inp, ['name'].concat(ty ? ['type'] : [], inp.required === false ? ['required'] : []));
      });
    }
    if (formulaOk(def.formula)) { w.put(1, '= ' + def.formula); used.push('formula'); }
    if (def.output !== undefined) { writeValue(w, 1, 'output', def.output); used.push('output'); }
    if (plainObj(def.reads)) {
      used.push('reads');
      const r = def.reads;
      w.put(1, 'reads');
      const u2 = [];
      if (plainObj(r.match) && Object.values(r.match).every(v => typeof v === 'string' || (plainObj(v) && Object.keys(v).length === 1 && 'const' in v && scalar(v.const)))) {
        u2.push('match');
        writeRest(w, 2, r, ['match']);
        if (!Object.keys(r.match).length) w.put(2, 'match');
        Object.entries(r.match).forEach(([k, v]) => w.put(2, typeof v === 'string' ? `match ${keyTok(k)} ${tok(v)}` : `match ${keyTok(k)} value ${tok(v.const)}`));
      } else writeRest(w, 2, r, []);
    }
    rest(def, used).forEach(k => writeValue(w, 1, k, def[k]));
  }

  /* The script of a definition. */
  function write(kind, id, def) {
    if (!KINDS.includes(kind)) throw new Error(`No script for kind ${kind}`);
    def = def || {};
    const w = Writer();
    const tk = TITLE_KEY[kind] || 'label';
    w.put(0, `${kind} ${tok(id)}${typeof def[tk] === 'string' ? ' ' + tok(def[tk]) : ''}`);
    if (def[tk] !== undefined && typeof def[tk] !== 'string') writeValue(w, 1, tk, def[tk]);
    if (kind === 'form') writeForm(w, def);
    else if (kind === 'structure') writeStructure(w, def);
    else if (kind === 'function') writeFunction(w, def);
    else { if (def.sites !== undefined) writeValue(w, 1, 'sites', def.sites); rest(def, [tk, 'sites', 'comments']).forEach(k => writeValue(w, 1, k, def[k])); }
    while (w.lines.length && w.lines[w.lines.length - 1].text === '') w.lines.pop();
    let text = w.lines.map(l => (l.text ? '  '.repeat(l.ind) + l.text : '')).join('\n') + '\n';
    // Comments go back where they were, by each line's address.
    const notes = plainObj(def.comments) ? def.comments : null;
    if (notes && Object.keys(notes).length) {
      const tree = parse(text);
      const paths = addPaths(tree.root, '', new Map());
      const byLine = new Map();
      paths.forEach((node, path) => byLine.set(node.line, path));
      const out = [];
      tree.lines.forEach((l, k) => {
        const path = byLine.get(k + 1);
        const pad = ' '.repeat(l.length - l.trimStart().length);
        const after = path && typeof notes[path + ' #'] === 'string' ? notes[path + ' #'] : null;
        // A formula runs to the end of its line, so a comment on a formula line goes above it.
        const hasFormula = after != null && lex(l.trim()).tokens.some(t => t.t === 'formula');
        if (path && typeof notes[path] === 'string') notes[path].split('\n').forEach(c => out.push(pad + '# ' + c));
        if (hasFormula) out.push(pad + '# ' + after);
        out.push(after != null && !hasFormula ? `${l}  # ${after}` : l);
      });
      if (typeof notes['end'] === 'string') { out.push(''); notes.end.split('\n').forEach(c => out.push('# ' + c)); }
      text = out.join('\n').replace(/\n*$/, '\n');
    }
    return text;
  }

  /* ---------- The reader ---------- */
  function read(text) {
    const tree = parse(text);
    const problems = tree.problems.slice();
    const say = (node, t) => problems.push({ line: node.line, text: t });
    const paths = addPaths(tree.root, '', new Map());
    const top = tree.root.children;
    const out = { kind: null, id: null, def: {}, problems, paths, lineOf: p => (paths.get(p) || {}).line || 1 };
    if (!top.length) { problems.push({ line: 1, text: 'Empty: start with what it is, e.g. form od-check "OD check"' }); return out; }
    const head = top[0];
    const kind = str(head.tokens[0]).toLowerCase();
    if (!KINDS.includes(kind)) { say(head, `The first line says what this is (${KINDS.join(', ')}), then its name, e.g. form od-check "OD check". "${str(head.tokens[0])}" isn't one of those.${mean(kind, KINDS)}`); return out; }
    if (top.length > 1) top.slice(1).forEach(n => say(n, `Everything belongs under line ${top[0].line}: indent this line, or remove it.`));
    out.kind = kind;
    out.id = head.tokens[1] ? str(head.tokens[1]) : null;
    if (!out.id) say(head, `Give the ${kind}'s name after the word ${kind}.`);
    const def = out.def;
    const tk = TITLE_KEY[kind] || 'label';
    if (head.tokens[2]) def[tk] = str(head.tokens[2]);
    if (head.tokens.length > 3) say(head, 'Too many words: the first line is the kind, the name, and a title in quotes.');

    // Comments, by address.
    const notes = {};
    paths.forEach((node, path) => {
      if (node.above && node.above.length) notes[path] = node.above.join('\n');
      if (node.comment != null) notes[path + ' #'] = node.comment;
    });
    if (head.above && head.above.length) notes[head.path] = head.above.join('\n');

    const setOnce = (obj, key, v, node) => {
      if (Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== undefined) { say(node, `${ALIAS_OUT[key] || key} is set twice${obj.__lines && obj.__lines[key] ? ` (also line ${obj.__lines[key]})` : ''}: keep one.`); return; }
      obj[key] = v;
    };
    const noKids = (node, what) => { if (node.children.length && !node.flagged) say(node.children[0], `Nothing belongs under ${what || 'this line'}: line ${node.children[0].line} is indented too far.`); };
    const parseJson = (node, tk2) => { try { return JSON.parse(str(tk2)); } catch (e) { say(node, 'The value after json isn\'t readable.'); return null; } };

    // The general form of any setting.
    function readGeneric(obj, node, opts) {
      opts = opts || {};
      const t0 = node.tokens[0];
      if (t0.t === 'formula') { setOnce(obj, 'formula', t0.v, node); noKids(node); return; }
      let key = str(t0);
      if (ALIAS_IN[key.toLowerCase()] && opts.alias !== false) key = ALIAS_IN[key.toLowerCase()];
      if (opts.known) { const m = opts.known.find(k => k.toLowerCase() === key.toLowerCase()); if (m) key = m; }
      const r = node.tokens.slice(1);
      if (VALUE_KEYS.has(key) && r.length === 1 && !node.children.length && r[0].t === 'word' && /^(list|item|json)$/i.test(r[0].v)) { setOnce(obj, key, r[0].v, node); return; }
      if (isWord(r[0], 'item')) {
        if (obj[key] === undefined) obj[key] = [];
        if (!Array.isArray(obj[key])) { say(node, `${key} is already set to one value above; "item" adds to a list.`); return; }
        if (r.length > 1) { obj[key].push(valueOf(node, r.slice(1))); noKids(node); }
        else obj[key].push(readObject(node.children, {}, opts.childOpts));
        return;
      }
      if (isWord(r[0], 'list')) { setOnce(obj, key, r.slice(1).map(val), node); noKids(node); return; }
      if (isWord(r[0], 'json')) { setOnce(obj, key, parseJson(node, r[1]), node); noKids(node); return; }
      if (LIST_KEYS.has(key) && r.length) { setOnce(obj, key, r.map(val), node); noKids(node); return; }
      if (!r.length) { setOnce(obj, key, readObject(node.children, {}, FORMULA_MAPS.has(key) ? opts.childOpts : opts.childOpts), node); return; }
      if (r.length === 1) { setOnce(obj, key, val(r[0]), node); noKids(node); return; }
      if (r.some(x => x.t === 'formula')) say(node, `The formula has to be the only thing after ${key}: ${key} = …`);
      else say(node, `Too many words after ${key}: put text with spaces in "quotes"${LIST_KEYS.has(key) ? '' : `, or write "${key} list …" for a list`}.`);
    }
    function valueOf(node, r) {
      if (isWord(r[0], 'list')) return r.slice(1).map(val);
      if (isWord(r[0], 'json')) return parseJson(node, r[1]);
      if (r.length > 1) say(node, 'Too many words: put text with spaces in "quotes".');
      return val(r[0]);
    }
    function readObject(nodes, obj, opts) { nodes.forEach(n => readGeneric(obj, n, opts)); return obj; }

    /* Layout */
    function readRows(nodes, rows) {
      nodes.forEach(n => {
        const kw = str(n.tokens[0]).toLowerCase();
        const r = n.tokens.slice(1);
        if (kw === 'row') {
          if (isWord(r[0], 'json')) { rows.push(parseJson(n, r[1])); return; }
          const bad = r.find(x => x.t !== 'word');
          if (bad) say(n, 'A row is field names, each followed by its width: row line 4  profile 4');
          rows.push(cellsOf(r.map(x => str(x))));
          noKids(n, 'a row');
          return;
        }
        if (kw === 'section') {
          const s = { section: r[0] ? str(r[0]) : '' };
          if (!r[0]) say(n, 'Give the section its title: section "Measurements"');
          readBlock(n.children, s);
          rows.push(s);
          return;
        }
        if (kw === 'tabs' || kw === 'steps') {
          const kind2 = kw.slice(0, -1);
          const o = {}; o[kw] = [];
          n.children.forEach(c => {
            const k2 = str(c.tokens[0]).toLowerCase();
            if (k2 === kind2) {
              const r2 = c.tokens.slice(1);
              if (isWord(r2[0], 'json')) { o[kw].push(parseJson(c, r2[1])); return; }
              const t = {}; t[kind2] = r2[0] ? str(r2[0]) : '';
              if (!r2[0]) say(c, `Give the ${kind2} its title: ${kind2} "Measurements"`);
              readBlock(c.children, t);
              o[kw].push(t);
            } else readGeneric(o, c);
          });
          if (!o[kw].length) say(n, `${kw} needs at least one ${kind2} under it.`);
          rows.push(o);
          return;
        }
        if (kw === 'item' || kw === 'json') { rows.push(isWord(n.tokens[0], 'json') ? parseJson(n, r[0]) : valueOf(n, r)); return; }
        say(n, `In a layout, a line is row, section, tabs or steps; "${str(n.tokens[0])}" isn't one of those.${mean(kw, ['row', 'section', 'tabs', 'steps'])}`);
      });
      return rows;
    }
    function readBlock(nodes, obj) {
      nodes.forEach(c => {
        const k = str(c.tokens[0]).toLowerCase();
        if (k === 'row' || k === 'section') { if (!obj.rows) obj.rows = []; readRows([c], obj.rows); }
        else if (k === 'rows' && isWord(c.tokens[1], 'list')) obj.rows = c.tokens.slice(2).map(val);
        else readGeneric(obj, c);
      });
    }
    function readLayout(node) {
      const r = node.tokens.slice(1);
      if (isWord(r[0], 'list')) return r.slice(1).map(val);
      if (isWord(r[0], 'json')) return parseJson(node, r[1]);
      if (r.length) say(node, 'layout is followed by its rows, indented under it.');
      return readRows(node.children, []);
    }

    /* Forms */
    function readForm(nodes, def) {
      const fieldKeys = n => { const f = FP.forms && FP.forms.describe && FP.forms.describe(n); return f && FP.forms.controls ? ((FP.forms.controls().find(c => c.name === n) || {}).settings || []).map(s => s.name) : null; };
      const formKeys = FP.forms && FP.forms.formSettings ? FP.forms.formSettings().map(s => s.name) : null;
      nodes.forEach(n => {
        const kw = str(n.tokens[0]).toLowerCase();
        const r = n.tokens.slice(1);
        if (kw === 'source') {
          if (isWord(r[0], 'json')) { (def.sources = def.sources || []).push(parseJson(n, r[1])); return; }
          const s = {};
          if (!r[0]) { say(n, 'Give the source a name and what it is: source odCheck item (or items, or value = …)'); return; }
          s.name = str(r[0]);
          if (!r[1] || r[1].t === 'formula') say(n, `Say what ${s.name} is after its name: item (one item), items (a list) or value (= a formula).`);
          else s.kind = str(r[1]).toLowerCase();
          const f = r.find(x => x.t === 'formula');
          if (f) s.formula = f.v;
          n.children.forEach(c => {
            const k = str(c.tokens[0]).toLowerCase();
            const cr = c.tokens.slice(1);
            if (k === 'id' && cr.length) {
              const w0 = str(cr[0]).toLowerCase();
              if (w0 === 'field' && cr[1]) s.id = { field: str(cr[1]) };
              else if (w0 === 'fixed' && cr[1]) s.id = { fixed: str(cr[1]) };
              else if (w0 === 'new') s.id = cr[1] ? { generate: true, prefix: str(cr[1]) } : { generate: true };
              else if (w0 === 'where' && cr[1] && cr[1].t === 'formula') s.id = { where: cr[1].v };
              else if (w0 === 'json') s.id = parseJson(c, cr[1]);
              else say(c, 'Say where the ID comes from: id field part, id fixed R-1, id new (or id new OD for a prefix), or id where = a rule.');
              noKids(c);
            } else readGeneric(s, c);
          });
          (def.sources = def.sources || []).push(s);
          return;
        }
        if (kw === 'read') {
          if (isWord(r[0], 'json')) { (def.acknowledge = def.acknowledge || []).push(parseJson(n, r[1])); return; }
          const a = {};
          if (r[0]) a.name = str(r[0]);
          readObject(n.children, a);
          (def.acknowledge = def.acknowledge || []).push(a);
          return;
        }
        if (kw === 'field') {
          if (isWord(r[0], 'json')) { (def.fields = def.fields || []).push(parseJson(n, r[1])); return; }
          if (!r[0] || !r[1]) { say(n, 'A field line is its name, its kind and its label: field qty number "Qty"'); if (!r[0]) return; }
          const f = { name: str(r[0]) };
          if (r[1]) f.control = str(r[1]);
          r.slice(2).forEach(x => {
            if (isWord(x, 'required')) f.required = true;
            else if (f.label === undefined && x.t !== 'formula') f.label = str(x);
            else say(n, `"${str(x)}" isn't understood here: after the label, only required can follow.`);
          });
          if (f.control && FP.forms && FP.forms.describe && !FP.forms.describe(f.control)) {
            const all = FP.forms.controls ? FP.forms.controls().map(c => c.name) : [];
            const near = all.find(c => c.toLowerCase() === f.control.toLowerCase());
            if (near) f.control = near;
            else say(n, `${f.control} isn't a kind of field.${mean(f.control, all) || ` The kinds are: ${all.join(', ')}.`}`);
          }
          const known = f.control ? fieldKeys(f.control) : null;
          n.children.forEach(c => {
            const k = str(c.tokens[0]).toLowerCase();
            if (k === 'column') {
              const cr = c.tokens.slice(1);
              const col = {};
              if (cr[0]) col.name = str(cr[0]); else say(c, 'Give the column its name: column qty');
              readObject(c.children, col);
              (f.columns = f.columns || []).push(col);
            } else readGeneric(f, c, { known });
          });
          (def.fields = def.fields || []).push(f);
          return;
        }
        if (kw === 'layout') { setOnce(def, 'layout', readLayout(n), n); return; }
        if (kw === 'button') {
          if (isWord(r[0], 'json')) { (def.buttons = def.buttons || []).push(parseJson(n, r[1])); return; }
          if (!r[0]) { say(n, 'Give the button a name: button save "Save"'); return; }
          const b = { name: str(r[0]) };
          if (r[1]) b.label = str(r[1]);
          if (r.length > 2) say(n, 'A button line is its name and its label in quotes.');
          n.children.forEach(c => {
            const k = str(c.tokens[0]).toLowerCase();
            const cr = c.tokens.slice(1);
            if (k === 'save' && cr.length <= 1 && !c.children.length) { setOnce(b, 'action', 'save', c); if (cr[0]) b.scope = str(cr[0]); }
            else if (k === 'open' && cr.length === 1 && !c.children.length) { setOnce(b, 'action', 'open', c); b.form = str(cr[0]); }
            else if (k === 'subform' && cr.length === 1 && !c.children.length) { setOnce(b, 'action', 'subform', c); b.subform = str(cr[0]); }
            else readGeneric(b, c);
          });
          (def.buttons = def.buttons || []).push(b);
          return;
        }
        if (kw === 'buttons' && isWord(r[0], 'list')) { def.buttons = r.slice(1).map(val); return; }
        if (kw === 'subform' && def.__sub) { say(n, 'A sub-form can\'t have sub-forms of its own.'); return; }
        if (kw === 'subform') {
          if (isWord(r[0], 'json')) { (def.subforms = def.subforms || []).push(parseJson(n, r[1])); return; }
          if (!r[0]) { say(n, 'Give the sub-form a name and a label: subform retest "Re-test"'); return; }
          const sf = { name: str(r[0]) };
          if (r[1]) sf.label = str(r[1]);
          if (r.length > 2) say(n, 'A sub-form line is its name and its label in quotes.');
          const rest2 = [];
          n.children.forEach(c => {
            const k = str(c.tokens[0]).toLowerCase();
            const cr = c.tokens.slice(1);
            if (k === 'title' && cr.length === 1 && cr[0].t === 'formula') { sf.title = cr[0].v; noKids(c); return; }
            if (k === 'repeat' && cr.length) {
              const w0 = str(cr[0]).toLowerCase();
              if (w0 === 'open' && cr.length === 1) sf.repeat = { open: true };
              else if (w0 === 'count' && cr[1] && cr[1].t === 'formula') sf.repeat = { count: cr[1].v };
              else if (w0 === 'count' && cr[1] && typeof val(cr[1]) === 'number') sf.repeat = { count: val(cr[1]) };
              else if (w0 === 'list' && cr[1] && cr[1].t === 'formula') sf.repeat = { list: cr[1].v };
              else if (w0 === 'json') sf.repeat = parseJson(c, cr[1]);
              else say(c, 'How many times: repeat count 3, repeat count = a formula, repeat list = a formula giving a list, or repeat open (as many as needed).');
              noKids(c);
              return;
            }
            if (k === 'saves' && cr.length === 1 && !c.children.length) { sf.saves = str(cr[0]); return; }
            if (['required', 'link'].includes(k)) { readGeneric(sf, c); return; }
            if (k === 'back' && cr.length >= 2 && cr.length <= 3 && !c.children.length) {
              const x = { to: str(cr[0]), from: str(cr[1]) };
              if (cr[2]) x.how = str(cr[2]);
              (sf.back = sf.back || []).push(x);
              return;
            }
            rest2.push(c);
          });
          const inner = { __sub: true };
          readForm(rest2, inner);
          delete inner.__sub;
          Object.keys(inner).forEach(k => { sf[k] = inner[k]; });
          (def.subforms = def.subforms || []).push(sf);
          return;
        }
        if (kw === 'media' && r[0] && !isWord(r[0], 'json') && !isWord(r[0], 'item') && !isWord(r[0], 'list')) {
          const m = { path: str(r[0]) };
          if (r[1]) m.title = str(r[1]);
          if (r.length > 2) say(n, 'A media line is the path of the file in the media folder and, in quotes, its title.');
          n.children.forEach(c => {
            const ck = str(c.tokens[0]).toLowerCase();
            const cr = c.tokens.slice(1);
            if (ck === 'tag' && cr[0]) { m.tags = m.tags || {}; const vals = cr.slice(1).map(x => str(x)); m.tags[str(cr[0])] = vals.length === 1 ? vals[0] : vals; if (!vals.length) say(c, `Give ${str(cr[0])} a value: tag ${str(cr[0])} D-1047`); noKids(c); }
            else if (ck === 'title' && cr[0]) m.title = str(cr[0]);
            else say(c, 'Under a media line: tag NAME VALUE (several values: tag die D-1047 D-1052).');
          });
          (def.media = def.media || []).push(m);
          return;
        }
        if (kw === 'print' && !r.length) {
          const p = {};
          n.children.forEach(c => { if (str(c.tokens[0]).toLowerCase() === 'layout') setOnce(p, 'layout', readLayout(c), c); else readGeneric(p, c); });
          setOnce(def, 'print', p, n);
          return;
        }
        readGeneric(def, n, { known: formKeys });
      });
    }

    /* Structures */
    function readStructure() {
      const rules = (FP.summary && FP.summary.rules) || [];
      head.children.forEach(n => {
        const kw = str(n.tokens[0]).toLowerCase();
        const r = n.tokens.slice(1);
        if (kw === 'id' && (r.length || !n.children.length)) {
          const t = {};
          r.forEach(x => {
            const w0 = str(x).toLowerCase();
            if (x.t === 'word' && (w0 === 'new' || w0 === 'entered') && !t.made) t.made = w0;
            else if (t.made === 'new' && t.prefix === undefined) t.prefix = str(x);
            else if (t.label === undefined && !t.made) t.label = str(x);
            else say(n, `"${str(x)}" isn't understood here: id "What it is called" entered (or new PREFIX).`);
          });
          setOnce(def, 'itemId', t, n);
          noKids(n);
          return;
        }
        if (kw === 'itemid' || (kw === 'id' && !r.length)) { setOnce(def, 'itemId', readObject(n.children, {}), n); return; }
        if (kw === 'live' && r.length === 1 && typeof val(r[0]) === 'number') { setOnce(def, 'live', { days: val(r[0]) }, n); noKids(n); return; }
        if (kw === 'container') {
          if (!r[0]) { say(n, 'Give the container its name: container qty'); return; }
          const name = str(r[0]);
          def.containers = def.containers || {};
          if (isWord(r[1], 'json')) { def.containers[name] = parseJson(n, r[2]); return; }
          const c = {};
          for (let k = 1; k < r.length; k++) {
            const w0 = str(r[k]);
            if (w0.toLowerCase() === 'from' && r[k + 1]) { c.from = str(r[k + 1]); k++; }
            else if (rules.includes(w0.toLowerCase()) && c.rule === undefined) c.rule = w0.toLowerCase();
            else say(n, `"${w0}" isn't understood here.${mean(w0, rules.concat('from')) || ` After the name: how saves combine (${rules.join(', ')}), and from a differently named value.`}`);
          }
          readObject(n.children, c);
          if (def.containers[name]) say(n, `container ${name} is written twice.`);
          def.containers[name] = c;
          return;
        }
        if (kw === 'containers' && !r.length && !n.children.length) { def.containers = def.containers || {}; return; }
        if (kw === 'calculated') {
          def.calculated = def.calculated || {};
          if (!r.length && !n.children.length) return;
          if (!r[0]) { say(n, 'Give the calculated value a name and its function: calculated daysOpen DaysBetween'); return; }
          const name = str(r[0]);
          if (isWord(r[1], 'json')) { def.calculated[name] = parseJson(n, r[2]); return; }
          const c = { fn: r[1] ? str(r[1]) : '' };
          if (!r[1]) say(n, `Say which function works out ${name}: calculated ${name} DaysBetween`);
          if (!isWord(r[2], 'none')) c.inputs = readObject(n.children, {}, { alias: false });
          else if (r.length > 3) say(n, 'Too many words.');
          def.calculated[name] = c;
          return;
        }
        if (kw === 'status') {
          if (isWord(r[0], 'list')) { def.status = []; return; }
          def.status = def.status || [];
          if (isWord(r[0], 'json')) { def.status.push(parseJson(n, r[1])); return; }
          if (!r[0] || r[0].t === 'formula') { say(n, 'A status line is the status, then = when it applies: status Received = receivedQty >= expectedQty'); return; }
          const s = { value: str(r[0]) };
          if (r[1] && r[1].t === 'formula') s.when = r[1].v;
          else if (r[1]) say(n, `After the status comes = and when it applies; put a status with spaces in "quotes".`);
          readObject(n.children, s);
          def.status.push(s);
          return;
        }
        readGeneric(def, n);
      });
    }

    /* Functions */
    function readFunction() {
      head.children.forEach(n => {
        const kw = str(n.tokens[0]).toLowerCase();
        const r = n.tokens.slice(1);
        if (kw === 'input') {
          def.inputs = def.inputs || [];
          if (isWord(r[0], 'json')) { def.inputs.push(parseJson(n, r[1])); return; }
          if (!r[0]) { say(n, 'Give the input a name: input profile text'); return; }
          const inp = { name: str(r[0]) };
          r.slice(1).forEach(x => {
            const w0 = str(x).toLowerCase();
            if (TYPES.includes(w0) && inp.type === undefined) inp.type = w0;
            else if (w0 === 'optional') inp.required = false;
            else say(n, `"${str(x)}" isn't understood here.${mean(w0, TYPES.concat('optional')) || ` After the name: its kind (${TYPES.join(', ')}), and optional.`}`);
          });
          readObject(n.children, inp);
          def.inputs.push(inp);
          return;
        }
        if (kw === 'inputs' && isWord(r[0], 'list')) { def.inputs = r.slice(1).map(val); return; }
        if (kw === 'reads' && !r.length) {
          const rd = {};
          n.children.forEach(c => {
            const k = str(c.tokens[0]).toLowerCase();
            const cr = c.tokens.slice(1);
            if (k === 'match' && cr.length >= 2) {
              rd.match = rd.match || {};
              const key = str(cr[0]);
              if (isWord(cr[1], 'value') && cr.length === 3) rd.match[key] = { const: val(cr[2]) };
              else if (cr.length === 2) rd.match[key] = str(cr[1]);
              else say(c, 'match is the value, then the input it equals (match profile profile), or value and a fixed value (match status value active).');
              noKids(c);
            } else if (k === 'match' && !cr.length && !c.children.length) rd.match = rd.match || {};
            else readGeneric(rd, c);
          });
          setOnce(def, 'reads', rd, n);
          return;
        }
        readGeneric(def, n);
      });
    }

    /* Media rules */
    if (kind === 'form') readForm(head.children, def);
    else if (kind === 'structure') readStructure();
    else if (kind === 'function') readFunction();
    else readObject(head.children, def);
    if (Object.keys(notes).length) def.comments = notes;
    problems.sort((a, b) => a.line - b.line);
    return out;
  }

  /* ---------- Where a check's message belongs ---------- */
  function lineFor(r, msg) {
    const has = p => r.paths.has(p);
    const at = p => r.paths.get(p).line;
    const find = (kw, name) => { const p = `${kw} ${name}`; if (has(p)) return at(p); const k = Array.from(r.paths.keys()).find(x => x.toLowerCase() === p.toLowerCase()); return k ? at(k) : null; };
    let m;
    // Addresses are under the first line: "form od-check / field qty".
    const base = r.kind || '';
    const findUnder = (kw, name) => { const p = `${base} / ${kw} ${name}`; if (r.paths.has(p)) return r.paths.get(p).line; const k = Array.from(r.paths.keys()).find(x => x.toLowerCase() === p.toLowerCase()); return k ? r.paths.get(k).line : null; };
    const findKw = kw => { const p = `${base} / ${kw}`; return r.paths.has(p) ? r.paths.get(p).line : null; };
    // A setting of a field, button or source: its own line when it has one.
    const setting = (kw, name, key) => {
      const p = `${base} / ${kw} ${name}`;
      const k = Array.from(r.paths.keys()).find(x => x.toLowerCase().startsWith((p + ' / ' + key).toLowerCase()));
      return k ? r.paths.get(k).line : null;
    };
    if ((m = /^Field ([A-Za-z0-9_]+): (?:([A-Za-z0-9_]+) is not a setting|([A-Za-z0-9_]+) is required)/.exec(msg))) return setting('field', m[1], m[2] || m[3]) || findUnder('field', m[1]) || 1;
    if ((m = /^Field ([A-Za-z0-9_]+) \(when\)/.exec(msg))) return setting('field', m[1], 'when') || findUnder('field', m[1]) || 1;
    if ((m = /^Field ([A-Za-z0-9_]+): (?:saves|keeps a copy in) /.exec(msg))) return setting('field', m[1], /keeps/.test(msg) ? 'snapshot' : 'saves') || findUnder('field', m[1]) || 1;
    if ((m = /^Field ([A-Za-z0-9_]+) options/.exec(msg))) return setting('field', m[1], 'optionsfrom') || findUnder('field', m[1]) || 1;
    if ((m = /^Field ([A-Za-z0-9_]+): .*(isn't a field or source|no function named|takes \d|missing|Unexpected|needs numbers|Unknown name|The formula)/.exec(msg))) return setting('field', m[1], '=') || findUnder('field', m[1]) || 1;
    if ((m = /^Field ([A-Za-z0-9_]+)/.exec(msg))) return findUnder('field', m[1]) || 1;
    if ((m = /^Button ([A-Za-z0-9_]+)/.exec(msg))) return findUnder('button', m[1]) || findKw('buttons') || 1;
    if ((m = /^Source ([A-Za-z0-9_]+)/.exec(msg))) return findUnder('source', m[1]) || 1;
    if ((m = /^Read before starting ([A-Za-z0-9_]+)/.exec(msg))) return findUnder('read', m[1]) || 1;
    if ((m = /^(?:Container|Calculated) ([A-Za-z0-9_]+)/.exec(msg)) || (m = /^([A-Za-z0-9_]+) is both a container/.exec(msg))) return findUnder('container', m[1]) || findUnder('calculated', m[1]) || 1;
    if ((m = /saves to ([A-Za-z0-9_]+), which would be/.exec(msg))) return findUnder('container', m[1]) || 1;
    if ((m = /^Status rule (\d+)/.exec(msg))) { const ps = Array.from(r.paths.keys()).filter(p => p.startsWith(base + ' / status ')); return ps[Number(m[1]) - 1] ? r.paths.get(ps[Number(m[1]) - 1]).line : 1; }
    if ((m = /^(?:Bad input name |Input )([A-Za-z0-9_]+)/.exec(msg))) return findUnder('input', m[1]) || 1;
    if ((m = /^tag ([A-Za-z0-9_]+)/.exec(msg)) || (m = /^([A-Za-z0-9_]+) can't be a tag name/.exec(msg))) return findUnder('tag', m[1]) || 1;
    if ((m = /^match (\S+) uses/.exec(msg))) { const p = `${base} / reads / match ${m[1]}`; return r.paths.has(p) ? r.paths.get(p).line : findKw('reads') || 1; }
    if (/^itemId|IDs are|enters the ID|makes a new ID/.test(msg)) return findKw('id') || 1;
    if (/^Layout/.test(msg)) return findKw('layout') || 1;
    if ((m = /^Form: ([A-Za-z0-9_]+) is not a setting/.exec(msg))) return findKw(m[1]) || 1;
    if (/^(Bad structure|from must|return needs|summary must|Over items|This lookup gives|window must)/.test(msg)) return findKw('reads') || 1;
    if (/^when: /.test(msg)) return findKw('when') || 1;
    if (/^kind /.test(msg)) return findKw('kind') || 1;
    if (/sites?\b|uses it at/.test(msg)) return findKw('sites') || 1;
    if (r.kind === 'function' && findKw('=')) return findKw('=');
    // A field named at the start: "Measured OD saves to …", "Qty and Count both save to …"
    if (r.kind === 'form' && Array.isArray(r.def.fields)) {
      if ((m = /saves to ([A-Za-z0-9_]+)\.([A-Za-z0-9_]+), but/.exec(msg))) {
        const f2 = r.def.fields.find(x => x && x.writes === `${m[1]}.${m[2]}`);
        if (f2) return setting('field', f2.name, 'saves') || findUnder('field', f2.name) || 1;
      }
      const f = r.def.fields.filter(x => x && [x.label, x.name].filter(Boolean).some(n => msg.startsWith(n + ' ') || msg.startsWith(n + ':'))).sort((a, b) => String(b.label || b.name).length - String(a.label || a.name).length)[0];
      if (f) return findUnder('field', f.name) || 1;
      if ((m = /^items\.([a-z0-9-]+)|^([a-z0-9-]+) IDs are/.exec(msg))) return findKw('items') || 1;
    }
    return 1;
  }

  /* ---------- What can come next (completion) ---------- */
  const TOP = {
    form: ['sites', 'source', 'read', 'field', 'layout', 'button', 'subform', 'media', 'print', 'launchable', 'approval', 'saveLabel', 'savedMessage', 'backLabel', 'nextLabel', 'refresh'],
    structure: ['sites', 'id', 'container', 'calculated', 'status', 'live', 'open'],
    function: ['sites', 'input', 'kind', 'gives', 'reads'],
  };
  function complete(text, lineNo, col) {
    const lines = String(text).split('\n');
    const line = lines[lineNo - 1] || '';
    const before = line.slice(0, col);
    const wm = /[^\s"]*$/.exec(before);
    const word = wm ? wm[0] : '';
    const from = col - word.length;
    const indent = line.length - line.trimStart().length;
    const parts = before.trim().split(/\s+/).filter(Boolean);
    const first = parts.length <= 1 && !/\s$/.test(before);
    // The lines this one belongs to: the nearest above with less indentation, and so on up.
    const chain = [];
    let need = indent;
    for (let k = lineNo - 2; k >= 0 && need > 0; k--) {
      const l = lines[k];
      if (!l.trim() || l.trim().startsWith('#')) continue;
      const ind = l.length - l.trimStart().length;
      if (ind < need) { chain.unshift(l.trim()); need = ind; }
    }
    const kind = chain.length ? chain[0].split(/\s+/)[0] : (parts[0] || '');
    const parent = chain.length ? chain[chain.length - 1].split(/\s+/) : [];
    let items = [];
    if (first) {
      if (!chain.length) items = KINDS;
      else if (chain.length === 1) items = TOP[kind] || ['sites'];
      else if (parent[0] === 'field' && parent[2]) {
        const c = FP.forms && FP.forms.controls ? FP.forms.controls().find(x => x.name === parent[2]) : null;
        items = ['saves', 'when', 'column'].concat(c ? c.settings.map(s => s.name).filter(n => !['name', 'label', 'control', 'required', 'writes'].includes(n)) : []);
      } else if (parent[0] === 'layout' || parent[0] === 'section' || parent[0] === 'tab' || parent[0] === 'step') items = ['row', 'section', 'tabs', 'steps', 'fold', 'when'];
      else if (parent[0] === 'tabs') items = ['tab'];
      else if (parent[0] === 'steps') items = ['step'];
      else if (parent[0] === 'button') items = ['save', 'open', 'when', 'saveAs', 'link', 'prefill', 'apply', 'scope', 'action'];
      else if (parent[0] === 'source') items = ['structure', 'id', 'filter', 'values', 'label'];
      else if (parent[0] === 'reads') items = ['structure', 'from', 'action', 'match', 'return', 'summary', 'window'];
      else if (parent[0] === 'tag') items = ['structure', 'pattern', 'column', 'value'];
      else if (parent[0] === 'read') items = ['label', 'show', 'formula', 'text', 'statement', 'every', 'when'];
    } else {
      const kw = parts[0];
      const pos = parts.length - (/\s$/.test(before) ? 0 : 1);
      if (kw === 'field' && pos === 2 && FP.forms && FP.forms.controls) items = FP.forms.controls().map(c => c.name);
      else if (kw === 'saves' && pos === 1) {
        // source.value pairs from this script's sources.
        const srcs = lines.map(l => l.trim().split(/\s+/)).filter(t => t[0] === 'source' && (t[2] === 'item'));
        items = [];
        srcs.forEach(t => {
          const at = lines.findIndex(l => l.trim().startsWith(`source ${t[1]} `));
          const st = lines.slice(at + 1, at + 6).map(l => l.trim().split(/\s+/)).find(x => x[0] === 'structure');
          const d = st && FP.defs.get('structure', st[1]);
          const names = new Set(Object.keys((d && d.def.containers) || {}));
          if (FP.map && st) FP.map.usedBy('structure', st[1]).forEach(u => { const m2 = /^saves (?:its value )?to (\w+)$/.exec(u.how || ''); if (m2) names.add(m2[1]); });
          names.forEach(n => items.push(`${t[1]}.${n}`));
        });
      } else if ((kw === 'structure' && pos === 1) || (kw === 'open' && pos === 1)) items = FP.defs.list(kw === 'open' ? 'form' : 'structure').filter(d => !d.retired).map(d => d.id);
      else if (kw === 'source' && pos === 2) items = ['item', 'items', 'value'];
      else if (kw === 'input' && pos === 2) items = TYPES;
      else if (kw === 'container' && pos === 2) items = (FP.summary && FP.summary.rules) || [];
      else if (kw === 'calculated' && pos === 2) items = FP.fn.list().map(f => f.name);
      else if (kw === 'id' && pos === 1 && kind === 'form') items = ['field', 'fixed', 'new', 'where'];
      else if (kw === 'id' && kind === 'structure') items = ['entered', 'new'];
      else if (kw === 'sites') items = ['all'];
      else if (kw === 'gives') items = TYPES;
    }
    const lw = word.toLowerCase();
    return { from, word, items: Array.from(new Set(items)).filter(x => x.toLowerCase().startsWith(lw) && x !== word).slice(0, 40) };
  }

  /* The shape the round-trip compares: key order aside, the same data. */
  const canon = v => (Array.isArray(v) ? v.map(canon) : plainObj(v) ? Object.keys(v).sort().reduce((o, k) => { if (v[k] !== undefined) o[k] = canon(v[k]); return o; }, {}) : v);
  function roundTrip(kind, id, def) {
    const text = write(kind, id, def);
    const r = read(text);
    const a = JSON.stringify(canon(def)), b = JSON.stringify(canon(r.def));
    return { ok: a === b && !r.problems.length && write(kind, id, r.def) === text, text, problems: r.problems, before: a, after: b };
  }

  /* ---------- The Script view in the editor ----------
   * Both views edit one draft: what is typed here is read into the draft as soon as it reads without a
   * problem, and the visual editor shows it. While it can't be read, the draft keeps the last good version
   * and ctx.scriptBroken says so. Problems from the publish checks are put on their lines. */
  const CSS = `
  .fsc{display:flex;flex-direction:column;gap:8px}
  .fsc-bar{display:flex;flex-wrap:wrap;align-items:center;gap:6px}
  .fsc-state{font-size:13px;font-weight:700;padding:4px 10px;border-radius:999px}
  .fsc-state.ok{background:#e5f4e4;color:#1a7f37}.fsc-state.bad{background:#fde3e0;color:#b42318}
  .fsc-banner{background:#fff6e5;border:1px solid #f0d9b0;border-radius:8px;padding:8px 12px;font-size:13px}
  .fsc-ed{display:grid;grid-template-columns:auto 1fr;border:1px solid #c9d0d9;border-radius:10px;background:#fff;overflow:hidden;font:13px/20px Consolas,"Cascadia Mono",monospace}
  .fsc-ed:focus-within{border-color:#1f5fbf;box-shadow:0 0 0 2px #c7d7ef}
  .fsc-gut{margin:0;padding:8px 6px 8px 8px;background:#f4f6f8;color:#8a94a3;text-align:right;user-select:none;border-right:1px solid #e3e7ec;min-width:44px;white-space:pre}
  .fsc-gut .x{color:#b42318;font-weight:700;cursor:pointer}
  .fsc-wrap{position:relative;overflow-x:auto}
  .fsc-wrap pre,.fsc-wrap textarea{margin:0;padding:8px 10px;font:inherit;white-space:pre;tab-size:2;border:0;box-sizing:border-box;min-width:100%}
  .fsc-wrap pre{position:absolute;inset:0 auto auto 0;pointer-events:none;color:#1b2633}
  .fsc-wrap textarea{position:relative;display:block;width:100%;resize:none;overflow:hidden;background:transparent;color:transparent;caret-color:#1b2633;outline:none}
  .fsc-wrap pre .ln.bad{background:#fde3e0}
  .fsc-wrap pre .k{color:#1f5fbf;font-weight:700}.fsc-wrap pre .s{color:#1a7f37}.fsc-wrap pre .n{color:#c2410c}.fsc-wrap pre .b{color:#7c3aed}
  .fsc-wrap pre .f{color:#5b21b6}.fsc-wrap pre .fn{color:#7c3aed;font-weight:700}.fsc-wrap pre .c{color:#8a94a3;font-style:italic}.fsc-wrap pre .m{color:#8a94a3}
  .fsc-comp{display:flex;flex-wrap:wrap;gap:4px;align-items:center;font-size:12px;color:#5b6573;min-height:26px}
  .fsc-comp button{font:12px Consolas,monospace;min-height:24px;padding:1px 8px;border:1px solid #c9d0d9;border-radius:6px;background:#fff;cursor:pointer}
  .fsc-comp button.on{border-color:#1f5fbf;background:#e8f0fb}
  .fsc-probs{display:flex;flex-direction:column;gap:2px;font-size:13px}
  .fsc-probs button{font:inherit;text-align:left;border:0;background:none;color:#b42318;cursor:pointer;padding:2px 0}
  .fsc-probs button b{color:#1b2633;margin-right:6px}`;
  const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  function paintFormula(f) {
    return esc(f).replace(/(&quot;|")((?:[^"\\]|\\.)*)"/g, '<span class="s">"$2"</span>').replace(/\b([A-Za-z][A-Za-z0-9_]*)(?=\()/g, '<span class="fn">$1</span>');
  }
  function paintLine(l) {
    const ind = l.length - l.trimStart().length;
    const body = l.slice(ind);
    if (!body) return '';
    const lx = lex(body);
    let html = ' '.repeat(ind), at = 0;
    const take = (to, cls) => { const piece = body.slice(at, to); html += cls ? `<span class="${cls}">${esc(piece)}</span>` : esc(piece); at = to; };
    lx.tokens.forEach((t, i) => {
      take(t.at);
      if (t.t === 'formula') { html += '<span class="m">=</span>' + `<span class="f">${paintFormula(body.slice(t.at + 1))}</span>`; at = body.length; return; }
      let end = t.at;
      if (t.t === 'text') { end = body.indexOf('"', t.at + 1); while (end > 0 && body[end - 1] === '\\') end = body.indexOf('"', end + 1); end = end < 0 ? body.length : end + 1; }
      else end = t.at + t.v.length;
      const w = t.t === 'word' ? t.v.toLowerCase() : '';
      take(end, i === 0 ? 'k' : t.t === 'text' ? 's' : NUM_RE.test(t.v) ? 'n' : /^(yes|no|none|list|item)$/.test(w) ? 'b' : '');
    });
    if (at < body.length) take(body.length, lx.comment != null ? 'c' : '');
    return html;
  }

  function view(draft, ctx, opts) {
    const ui = FP.editor && FP.editor.ui;
    if (!ui) throw new Error('The script view needs the editor');
    const { el, btn } = ui;
    if (!document.getElementById('fp-script-css')) { const st = el('style'); st.id = 'fp-script-css'; st.textContent = CSS; document.head.appendChild(st); }
    const kind = opts.kind, id = opts.id;
    const root = el('div', 'fsc');
    const bar = el('div', 'fsc-bar');
    const state = el('span', 'fsc-state');
    const tidyBtn = btn('Tidy', 'small');
    tidyBtn.title = 'Write it in the standard order and spacing';
    const nextBtn = btn('Next problem ↓', 'small');
    nextBtn.title = 'F8';
    bar.append(state, tidyBtn, nextBtn, el('span', 'fpe-hint', 'Tab offers what can come next. # starts a comment, kept with the definition.'));
    const banner = el('div', 'fsc-banner'); banner.hidden = true;
    const ed = el('div', 'fsc-ed');
    const gut = el('pre', 'fsc-gut');
    const wrap = el('div', 'fsc-wrap');
    const hl = el('pre');
    const ta = el('textarea');
    ta.spellcheck = false; ta.setAttribute('autocapitalize', 'off'); ta.setAttribute('autocomplete', 'off'); ta.wrap = 'off';
    wrap.append(hl, ta);
    ed.append(gut, wrap);
    const comp = el('div', 'fsc-comp');
    const probsBox = el('div', 'fsc-probs');
    root.append(bar, banner, ed, comp, probsBox);

    let text = ctx.scriptText && ctx.scriptBroken ? ctx.scriptText : write(kind, id, draft);
    ta.value = text;
    let lastRead = read(text);
    let syntax = [], checks = [];
    // While it can't be read, only what stops it being read: the checks are of the last version that could.
    const all = () => (syntax.length ? syntax : checks).slice().sort((a, b) => a.line - b.line);
    function paint() {
      const lines = ta.value.split('\n');
      const bad = new Map();
      all().forEach(p => { if (!bad.has(p.line)) bad.set(p.line, []); bad.get(p.line).push(p.text); });
      hl.innerHTML = lines.map((l, k) => `<span class="ln${bad.has(k + 1) ? ' bad' : ''}">${paintLine(l)}</span>`).join('\n') + '\n';
      gut.innerHTML = lines.map((_, k) => (bad.has(k + 1) ? `<span class="x" data-line="${k + 1}" title="${esc(bad.get(k + 1).join('\n'))}">✗ ${k + 1}</span>` : String(k + 1))).join('\n');
      ta.style.height = (lines.length * 20 + 18) + 'px';
      hl.style.width = ta.scrollWidth + 'px';
      const n = all().length;
      state.textContent = n ? `✗ ${n} to fix` : '✓ No problems';
      state.className = 'fsc-state ' + (n ? 'bad' : 'ok');
      probsBox.replaceChildren(...all().map(p => { const b = btn('', null, () => goLine(p.line)); b.append(el('b', null, `line ${p.line}`), document.createTextNode(p.text)); return b; }));
      banner.hidden = !syntax.length;
      banner.textContent = syntax.length ? 'The script can\'t be read until the problems marked ✗ are fixed. Until then the visual editor keeps the last version that could be read, and publishing waits.' : '';
    }
    gut.onclick = e => { const x = e.target.closest('.x'); if (x) goLine(Number(x.dataset.line)); };
    function goLine(n) {
      const lines = ta.value.split('\n');
      const start = lines.slice(0, n - 1).reduce((a, l) => a + l.length + 1, 0);
      ta.focus();
      ta.setSelectionRange(start + (lines[n - 1] || '').length - (lines[n - 1] || '').trimStart().length, start + (lines[n - 1] || '').length);
      const r = ta.getBoundingClientRect();
      window.scrollTo({ top: window.scrollY + r.top + (n - 1) * 20 - window.innerHeight / 3 });
    }
    nextBtn.onclick = () => {
      const cur = ta.value.slice(0, ta.selectionStart).split('\n').length;
      const list = all();
      const nx = list.find(p => p.line > cur) || list[0];
      if (nx) goLine(nx.line);
    };
    // Reading what is typed: into the draft when it can be read.
    function apply() {
      text = ta.value;
      const r = read(text);
      lastRead = r;
      syntax = r.problems.slice();
      if (r.kind && (r.kind !== kind || r.id !== id)) syntax.unshift({ line: 1, text: `This is ${kind} ${id}. The first line can't change what it is or its name: keep "${kind} ${id}" (a copy under a new name is made from the library).` });
      ctx.scriptBroken = syntax.length ? syntax : null;
      ctx.scriptText = text;
      if (ctx.scriptState) ctx.scriptState(!!syntax.length);
      if (!syntax.length) {
        Object.keys(draft).forEach(k => delete draft[k]);
        Object.assign(draft, r.def);
        ctx.changed();
      }
      paint();
    }
    // Publish checks, on their lines.
    ctx.problemsChanged = list => { checks = (list || []).map(t => ({ line: lineFor(lastRead, t), text: t })); paint(); };
    ctx.goToProblem = () => { const p = all()[0]; if (p) goLine(p.line); };
    if (ctx.problems) checks = ctx.problems.map(t => ({ line: lineFor(lastRead, t), text: t }));
    let tm = null;
    ta.addEventListener('input', () => { paint(); comp.replaceChildren(); clearTimeout(tm); tm = setTimeout(apply, 300); });
    ta.addEventListener('scroll', () => { hl.style.transform = `translate(${-ta.scrollLeft}px, 0)`; });
    tidyBtn.onclick = () => {
      const r = read(ta.value);
      if (r.problems.length || r.kind !== kind) { ui.toast('Fix the problems marked ✗ first: Tidy rewrites what it can read.', true); return; }
      ta.value = write(kind, id, r.def);
      apply();
    };
    // Keys: Tab offers what can come next; Enter keeps the indent; F8 goes to the next problem.
    let offer = null;
    function showOffer(items, from, word) {
      offer = { items, from, word, at: 0 };
      comp.replaceChildren(el('span', null, 'Tab:'), ...items.map((x, i) => { const b = btn(x, i === 0 ? 'on' : '', () => { insert(x); }); return b; }));
    }
    function insert(x) {
      if (!offer) return;
      const pos = ta.selectionStart;
      const lineStart = ta.value.lastIndexOf('\n', pos - 1) + 1;
      const a = lineStart + offer.from;
      ta.setRangeText(x + ' ', a, pos, 'end');
      offer = null; comp.replaceChildren();
      ta.focus();
      ta.dispatchEvent(new Event('input'));
    }
    ta.addEventListener('keydown', e => {
      if (e.key === 'F8') { e.preventDefault(); nextBtn.onclick(); return; }
      if (e.key === 'Tab' && !e.shiftKey) {
        e.preventDefault();
        const pos = ta.selectionStart;
        const before = ta.value.slice(0, pos);
        const lineNo = before.split('\n').length;
        const col = pos - (before.lastIndexOf('\n') + 1);
        const c = complete(ta.value, lineNo, col);
        if (offer && offer.items.length > 1 && offer.word === c.word) { offer.at = (offer.at + 1) % offer.items.length; Array.from(comp.querySelectorAll('button')).forEach((b, i) => b.classList.toggle('on', i === offer.at)); return; }
        if (c.items.length === 1) { offer = { items: c.items, from: c.from, word: c.word, at: 0 }; insert(c.items[0]); return; }
        if (c.items.length) { showOffer(c.items, c.from, c.word); return; }
        ta.setRangeText('  ', pos, ta.selectionEnd, 'end'); ta.dispatchEvent(new Event('input'));
        return;
      }
      if (e.key === 'Enter' && offer && comp.children.length) { e.preventDefault(); insert(offer.items[offer.at]); return; }
      if (e.key === 'Escape') { offer = null; comp.replaceChildren(); return; }
      if (e.key === 'Enter') {
        e.preventDefault();
        const pos = ta.selectionStart;
        const line = ta.value.slice(ta.value.lastIndexOf('\n', pos - 1) + 1, pos);
        let ind = line.length - line.trimStart().length;
        if (!line.trim()) { const above = ta.value.slice(0, pos).split('\n').reverse().find(l => l.trim()); ind = above ? above.length - above.trimStart().length : 0; }
        ta.setRangeText('\n' + ' '.repeat(ind), pos, ta.selectionEnd, 'end');
        ta.dispatchEvent(new Event('input'));
      }
    });
    syntax = lastRead.problems.slice();
    if (ctx.scriptBroken && ctx.scriptText === text) syntax = ctx.scriptBroken;
    paint();
    return root;
  }

  FP.script = { KINDS, write, read, lineFor, complete, roundTrip, lex, tok, view };

  /* Registered last, so a module that failed partway never reports as loaded. */
  (window.FP.modules = window.FP.modules || {})['fp-script'] = '0.42.0';
})();
