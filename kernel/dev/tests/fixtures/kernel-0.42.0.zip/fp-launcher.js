/* Form Platform runtime: launchers (step 19)
 * Load last, after fp-defs.js.
 *
 * FP.launcher.start() runs a launcher page: the bar (title, saving state, terminal
 * and site, Print, who is signed in), the startup and sign-in gates, and the form.
 * Which form: window.FP_LAUNCH = { form, version } in a launcher file, or
 * launcher.html?form=id (&version=3).
 *
 *   version "latest"  follows each newly published version (reloading when the form is clean)
 *   version 3         stays on version 3, a trial version included, whatever is published after
 *
 * FP.launchers makes launcher files: one small HTML file per launchable form in
 * the data folder's launchers folder. Each loads whichever release of the platform
 * runs (../runtime/releases.js, through ../runtime/boot.js), so an installed update
 * reaches every launcher on every terminal, and one file works on every terminal
 * (the terminal ID comes from the device). See fp-updates.js.
 */
(function () {
  'use strict';

  const FP = window.FP;
  if (!FP || !FP.defs || !FP.forms) throw new Error('Load fp-defs.js before fp-launcher.js');

  const VERSION = '0.42.0';
  /* The runtime, in load order. */
  const KERNEL = ['fp-config', 'fp-core', 'fp-identity', 'fp-entry', 'fp-session', 'fp-formula', 'fp-current', 'fp-sites', 'fp-lookup',
    'fp-users', 'fp-media', 'fp-sources', 'fp-forms', 'fp-controls', 'fp-visuals', 'fp-defs', 'fp-launcher', 'fp-updates'];
  const LAUNCHERS = ['launchers'];

  /* Runs before any kernel file in a launcher file: a missing or broken file shows a red banner instead of a blank page. */
  const preamble = where => `window.__fpProblems = [];
window.__fpReport = function (msg) {
  window.__fpProblems.push(msg);
  var show = function () {
    var b = document.getElementById('fp-problems');
    if (!b) { b = document.createElement('div'); b.id = 'fp-problems';
      b.style.cssText = 'position:sticky;top:0;z-index:10000;background:#fde8e6;color:#7a1a12;border-bottom:2px solid #b42318;padding:12px 16px;font:14px/1.45 system-ui,"Segoe UI",sans-serif;white-space:pre-wrap';
      document.body.prepend(b); }
    b.textContent = 'Problem found. This page will not work until it is fixed:\\n- ' + window.__fpProblems.join('\\n- ');
  };
  if (document.body) show(); else document.addEventListener('DOMContentLoaded', show);
};
window.addEventListener('error', function (e) {
  var t = e.target;
  if (t && t.tagName === 'SCRIPT') window.__fpReport('Could not load ' + t.getAttribute('src') + '. ${where}');
  else if (e.message && e.message !== 'Script error.' && !/ResizeObserver loop/.test(e.message)) window.__fpReport(e.message + (e.filename ? ' (' + e.filename.split('/').pop() + ' line ' + e.lineno + ')' : ''));
}, true);
window.addEventListener('unhandledrejection', function (e) { window.__fpReport('Unhandled error: ' + (e.reason && e.reason.message || e.reason)); });`;

  const CSS = `
  *{box-sizing:border-box}
  body{margin:0;background:#f4f6f8;color:#1b1f24;font:16px/1.45 system-ui,"Segoe UI",sans-serif}
  .fpl-bar{position:sticky;top:0;z-index:50;display:flex;align-items:center;gap:12px;padding:10px 16px;background:#1b2633;color:#fff}
  .fpl-bar h1{font-size:18px;margin:0;flex:1 1 auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .fpl-bar h1 small{font-size:13px;font-weight:600;color:#1b2633;background:#f2c94c;border-radius:6px;padding:2px 7px;margin-left:8px;vertical-align:2px}
  .fpl-meta{font-size:13px;color:#c6d0dc;white-space:nowrap}
  .fpl-bar button{font:inherit;font-size:14px;min-height:40px;padding:6px 12px;border-radius:10px;border:1px solid #4a5a6c;background:#26364a;color:#fff;cursor:pointer}
  .fpl-dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#2fbf5b;margin-right:6px;vertical-align:middle}
  .fpl-dot.wait{background:#e0a100}.fpl-dot.bad{background:#e5484d}
  .fpl-main{max-width:1100px;margin:0 auto;padding:18px 16px 0}
  .fpl-notice{background:#fdf3d8;color:#6b4a00;border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:14px}
  .fpl-notice.info{background:#e8f0fb;color:#1d3f73}
  .fpl-notice button{margin-left:8px;font:inherit;font-size:14px;padding:4px 10px;border-radius:8px;border:1px solid #c9a24a;background:#fff;cursor:pointer}
  .fpl-menu{position:fixed;z-index:60;background:#fff;color:#1b1f24;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.25);padding:6px;min-width:220px}
  .fpl-menu button{display:block;width:100%;text-align:left;font:inherit;min-height:48px;padding:8px 14px;border:0;border-radius:8px;background:none;cursor:pointer}
  .fpl-menu button:hover{background:#eef1f5}
  .fpl-menu small{display:block;color:#5b6573;font-size:13px}
  .fpl-err{background:#fde8e6;color:#7a1a12;border-radius:10px;padding:14px;white-space:pre-wrap}
  .fpl-home{display:flex;flex-direction:column;gap:14px;padding-bottom:24px}
  .fpl-tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}
  .fpl-tile{display:flex;flex-direction:column;justify-content:center;gap:4px;min-height:84px;padding:12px 16px;border:1px solid #d9dee5;border-left:5px solid #2a78d6;border-radius:12px;background:#fff;color:#1b1f24;font:inherit;text-align:left;cursor:pointer}
  .fpl-tile b{font-size:17px}.fpl-tile:hover{border-color:#9db8dc}
  .fpl-tile.small{min-height:60px;border-left-color:#94a3b8}.fpl-tile.small b{font-size:15px}
  .fpl-cap{font-size:13px;font-weight:700;color:#5b6573;margin-top:4px}
  .fpl-card{background:#fff;border:1px solid #d9dee5;border-radius:12px;padding:14px 16px}
  .fpl-card.quiet{background:#fbfcfd}
  .fpl-card h2{margin:0 0 6px;font-size:19px}.fpl-card h3{margin:0 0 4px;font-size:16px}.fpl-card p{margin:0 0 8px}.fpl-card ul{margin:4px 0 0;padding-left:20px}
  .fpl-sub{color:#5b6573;font-size:14px}
  .fpl-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:8px}
  .fpl-row button,.fpl-row select,.fpl-row input{font:inherit;font-size:15px;min-height:44px;padding:6px 14px;border-radius:10px;border:1px solid #c9d0d9;background:#fff}
  .fpl-row input{flex:1 1 200px}
  .fpl-row button{cursor:pointer}.fpl-row button.primary{background:#1f5fbf;border-color:#1f5fbf;color:#fff;font-weight:600}
  .fpl-approvals{display:flex;flex-direction:column;gap:8px}.fpl-approvals>h2{margin:0;font-size:19px}
  .fpl-appr{border-left:5px solid #b45309}
  .fpl-entry{display:flex;flex-wrap:wrap;gap:4px 10px;font-size:14px;padding:4px 0;border-bottom:1px solid #eef1f5}
  .fpl-this summary{cursor:pointer;font-weight:600}
  @media print{.fpl-bar,.fpl-notice{display:none!important}}
  @media (max-width:640px){.fpl-meta.term{display:none}}`;

  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const button = (text, cls, onclick) => { const b = el('button', cls, text); b.type = 'button'; if (onclick) b.onclick = onclick; return b; };
  const timeOf = iso => { const d = new Date(iso); return isNaN(d) ? '' : (d.toDateString() === new Date().toDateString() ? d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : d.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })); };
  const formTitle = id => { const d = FP.defs.get('form', id); return (d && d.def && d.def.title) || id; };

  /* ---------- A launcher page ----------
   * One launcher for every terminal (0.41). With no form named it is the terminal's home screen: who signs in
   * decides what it shows. A user sees the forms of this terminal's group (or the terminal's own list);
   * supervisors and up see those, then every form at the site, and a supervisor sees what waits for their
   * approval first. A form named in the address or a launcher file opens straight away, by the same rules:
   * a user who can't use it here is told so and offered to sign in as someone who can.
   * Until a site has any terminal group or terminal list, everyone there sees every form (as before 0.41). */
  function start() {
    const mods = FP.modules || {};
    const wrong = KERNEL.filter(m => mods[m] !== VERSION).map(m => (mods[m]
      ? `${m}.js is version ${mods[m]}; this launcher needs ${VERSION}. Replace it with the new copy.`
      : `${m}.js did not load, or stopped with an error. Replace it with the new copy.`));
    if (wrong.length) { wrong.forEach(window.__fpReport); return; }

    const st = el('style'); st.textContent = CSS; document.head.appendChild(st);
    const bar = el('div', 'fpl-bar');
    const homeBtn = button('⌂ Home'); homeBtn.hidden = true;
    const titleEl = el('h1', null, 'Loading…');
    const saved = el('span', 'fpl-meta');
    const dot = el('span', 'fpl-dot');
    const outbox = el('span', null, 'Saved');
    saved.append(dot, outbox);
    const term = el('span', 'fpl-meta term');
    const printBtn = button('Print'); printBtn.hidden = true;
    const editorBtn = button('Editor'); editorBtn.hidden = true;
    const who = button('Sign in');
    bar.append(homeBtn, titleEl, saved, term, printBtn, editorBtn, who);
    const main = el('main', 'fpl-main');
    const notice = el('div');
    const host = el('div');
    // ids for pages and tests that look for these parts
    [[titleEl, 'title'], [outbox, 'outbox'], [dot, 'dot'], [term, 'term'], [printBtn, 'print'], [who, 'who'], [notice, 'notice'], [host, 'form'], [homeBtn, 'home'], [editorBtn, 'editor']].forEach(([n, id]) => { n.id = id; });
    main.append(notice, host);
    document.body.prepend(bar, main);

    const launch = window.FP_LAUNCH || {};
    const q = new URLSearchParams(location.search);
    const oneForm = !!launch.form;                // a launcher file for one form: no home screen
    let formId = launch.form || q.get('form') || null;
    const want = launch.version != null ? launch.version : q.get('version');
    let pinned = want != null && want !== '' && want !== 'latest' ? Number(want) : null;
    let inst = null;
    let titleText = formId || 'Form';
    let place = { forms: [], group: null, name: '', setUp: false };
    let termText = '';

    const setTitle = (t, doc) => {
      titleText = t;
      document.title = t;
      titleEl.replaceChildren(document.createTextNode(t));
      if (formId && pinned != null) titleEl.appendChild(el('small', null, `v${pinned}${doc && doc.trial ? ' trial' : ''}`));
    };
    function showOutbox(s) {
      s = s || FP.outbox.status();
      if (s.pending > 0) { dot.className = 'fpl-dot ' + (s.state === 'waiting' ? 'bad' : 'wait'); outbox.textContent = `${s.pending} waiting to save`; }
      else { dot.className = 'fpl-dot'; outbox.textContent = 'All saved'; }
      if (s.state === 'waiting' && s.lastError) outbox.title = s.lastError;
    }
    async function showUser() {
      const u = await FP.users.current();
      const role = u ? FP.users.topRole(u.roles) : 'user';
      who.textContent = u ? (role === 'user' ? u.name : `${u.name} · ${FP.users.ROLE_LABEL[role].toLowerCase()}`) : 'Sign in';
      editorBtn.hidden = !(u && await FP.users.can(FP.defs.publishRole));
    }
    const say = (text, kind, btn) => {
      const n = el('div', 'fpl-notice' + (kind ? ' ' + kind : ''), text);
      if (btn) n.appendChild(btn);
      notice.replaceChildren(n);
    };
    // The editor sits next to this launcher (runtime/editor.html in the data folder).
    const editorUrl = () => (window.FP_BOOT && window.FP_BOOT.base ? window.FP_BOOT.base : '') + 'editor.html';
    editorBtn.onclick = () => window.open(editorUrl(), '_blank');

    /* This terminal: its group or own list of forms, and whether its site has any set up yet. */
    async function loadPlace() {
      const tid = FP.identity.terminalId, site = FP.identity.site;
      const ft = await FP.groups.forTerminal(tid).catch(() => ({ group: null, forms: [], name: '' }));
      const groups = await FP.groups.list().catch(() => []);
      const ts = await FP.groups.terminals().catch(() => new Map());
      const reg = await FP.identity.all().catch(() => []);
      const siteOf = id => (reg.find(r => r.terminalId === id) || {}).site;
      const setUp = groups.some(g => g.site === site) || Array.from(ts.entries()).some(([id, t]) => t.forms && t.forms.length && (id === tid || siteOf(id) === site));
      const usable = id => { const d = FP.defs.get('form', id); return !!(d && !d.retired && FP.defs.usedHere('form', id)); };
      place = { group: ft.group, name: ft.name, forms: ft.forms.filter(usable), setUp };
      termText = `${ft.group ? ft.group.name + ' · ' : ''}${tid}${ft.name ? ' ' + ft.name : ''}`;
      term.textContent = `${termText} · ${site}`;
      FP.sites.current().then(x => { if (x) term.textContent = `${termText} · ${x.name}`; }).catch(() => {});
    }
    const siteForms = () => FP.defs.list('form').filter(d => !d.retired && d.def && d.def.launchable && FP.defs.usedHere('form', d.id))
      .sort((a, b) => formTitle(a.id).localeCompare(formTitle(b.id)));
    async function mayOpen(id) {
      if (await FP.users.can('supervisor')) return true;
      return !place.setUp || place.forms.includes(id);
    }

    /* A pinned form: what it was checked against when published, and what is in use now. */
    function pinNotes(doc) {
      const latest = FP.defs.get('form', formId);
      const notes = [];
      if (latest && latest.version !== doc.version) notes.push(`This launcher stays on version ${doc.version}${doc.trial ? ' (a trial)' : ''}; version ${latest.version} is the current one.`);
      const changed = Object.entries(doc.uses || {}).map(([key, v]) => {
        const [kind, id] = key.split('/');
        const now = FP.defs.get(kind, id);
        return now && now.version !== v ? `${FP.defs.LABELS[kind]} ${id} v${v} → v${now.version}` : null;
      }).filter(Boolean);
      if (changed.length) notes.push(`Changed since this version was published: ${changed.join(', ')}.`);
      if (notes.length) say(notes.join(' '), 'info');
    }

    /* Someone who can't use this form here: say so, and offer to sign in as someone who can. */
    async function refuse() {
      const u = await FP.users.current();
      const t = formTitle(formId);
      setTitle(t);
      printBtn.hidden = true;
      const box = el('div', 'fpl-card');
      box.appendChild(el('h2', null, `${t} isn't on ${FP.identity.terminalId}`));
      box.appendChild(el('p', null, `${u ? u.name : 'You'} can fill in ${place.group ? `the forms of ${place.group.name}` : `${FP.identity.terminalId}'s forms`} here. A supervisor can fill in any form at this site, or ask one to add ${t} to this terminal.`));
      const row = el('div', 'fpl-row');
      row.appendChild(button('Sign in as someone who can', 'primary', async () => { await FP.users.signOut('switched'); await signInAgain(); }));
      if (!oneForm) row.appendChild(button('Go to this terminal\'s forms', null, () => goHome()));
      box.appendChild(row);
      host.replaceChildren(box);
    }

    async function openForm() {
      if (!formId) return goHome();
      homeBtn.hidden = oneForm;
      if (inst) { inst.destroy(); inst = null; }
      notice.replaceChildren();
      if (!(await mayOpen(formId))) return refuse();
      try {
        let doc;
        if (pinned != null) {
          doc = await FP.defs.version('form', formId, pinned);
          if (!doc) throw new Error(`Form ${formId} has no version ${pinned}. Make this launcher again, pinned to a version that exists.`);
          if (doc.retired) throw new Error(`Version ${pinned} of form ${formId} retired it.`);
          inst = await FP.forms.open(host, formId, { doc });
        } else {
          inst = await FP.forms.open(host, formId);
          doc = FP.defs.get('form', formId);
        }
        setTitle(doc.def.title || formId, doc);
        printBtn.hidden = !inst.canPrint();
        if (pinned != null) pinNotes(doc);
        approvalsNote();
      } catch (e) {
        host.replaceChildren(el('div', 'fpl-err', e.message));
        setTitle(formId);
      }
    }

    /* ---------- Home: approvals first (supervisors), then this terminal's forms ---------- */
    async function goHome() {
      if (oneForm) return openForm();
      if (inst && inst.isDirty() && !confirm('Leave this form? What you typed stays on this terminal as a draft.')) return;
      if (inst) { inst.destroy(); inst = null; }
      formId = null; pinned = null;
      history.replaceState(null, '', location.pathname);
      homeBtn.hidden = true; printBtn.hidden = true;
      notice.replaceChildren();
      await loadPlace();
      setTitle(place.group ? place.group.name : 'Forms');
      await paintHome();
    }
    function pick(id) {
      formId = id; pinned = null;
      history.replaceState(null, '', `${location.pathname}?form=${encodeURIComponent(id)}`);
      openForm();
    }
    const tile = (id, small) => {
      const t = el('button', 'fpl-tile' + (small ? ' small' : ''));
      t.type = 'button';
      t.appendChild(el('b', null, formTitle(id)));
      t.onclick = () => pick(id);
      t.dataset.form = id;
      return t;
    };
    async function paintHome() {
      const u = await FP.users.current();
      const sup = await FP.users.can('supervisor');
      const page = el('div', 'fpl-home');
      if (sup) {
        const waiting = await FP.approvals.list(FP.identity.site).catch(() => []);
        if (waiting.length) page.appendChild(approvalsPart(waiting));
      } else if (u) {
        const mine = (await FP.approvals.list(FP.identity.site).catch(() => [])).filter(a => a.userId === u.id);
        if (mine.length) {
          const box = el('div', 'fpl-card quiet');
          box.appendChild(el('h3', null, `Waiting for a supervisor's approval: ${mine.length}`));
          const ul = el('ul');
          mine.forEach(a => ul.appendChild(el('li', null, `${a.title} · ${timeOf(a.at)}${a.summary ? ' · ' + a.summary : ''}`)));
          box.appendChild(ul);
          page.appendChild(box);
        }
      }
      const shown = place.setUp ? place.forms : (sup ? [] : siteForms().map(d => d.id));
      if (shown.length) {
        if (sup) page.appendChild(el('div', 'fpl-cap', `Forms on ${place.group ? place.group.name : FP.identity.terminalId}`));
        const grid = el('div', 'fpl-tiles');
        shown.forEach(id => grid.appendChild(tile(id)));
        page.appendChild(grid);
      } else if (!sup) {
        page.appendChild(el('div', 'fpl-card', `No forms on ${FP.identity.terminalId} yet: ask a supervisor.`));
      }
      if (sup) {
        const rest = siteForms().filter(d => !shown.includes(d.id));
        if (rest.length) {
          const site = await FP.sites.current().catch(() => null);
          page.appendChild(el('div', 'fpl-cap', shown.length ? `Every form at ${site ? site.name : FP.identity.site}` : `Forms at ${site ? site.name : FP.identity.site}${place.setUp ? ` (none set for ${FP.identity.terminalId} yet)` : ''}`));
          const grid = el('div', 'fpl-tiles');
          rest.forEach(d => grid.appendChild(tile(d.id, true)));
          page.appendChild(grid);
        }
      }
      if (await FP.users.can('admin')) page.appendChild(terminalPart());
      host.replaceChildren(page);
    }

    /* What waits for a supervisor's approval, oldest first: approve it (it is saved) or not (it isn't). */
    function approvalsPart(waiting) {
      const box = el('section', 'fpl-approvals');
      box.appendChild(el('h2', null, `Waiting for your approval: ${waiting.length}`));
      waiting.forEach(a => {
        const card = el('div', 'fpl-card fpl-appr');
        card.dataset.approval = a.id;
        card.appendChild(el('h3', null, a.title));
        card.appendChild(el('p', 'fpl-sub', `${a.userName || 'Someone'} · ${FP.identity.label(a.terminalId)} · ${timeOf(a.at)}`));
        if (a.summary) card.appendChild(el('p', null, a.summary));
        const more = el('details');
        more.appendChild(el('summary', null, 'Everything it saves'));
        (a.entries || []).forEach(e => {
          const vals = Object.entries(e.values || {}).filter(([, v]) => v != null && v !== '' && typeof v !== 'object');
          const d = el('div', 'fpl-entry');
          d.appendChild(el('b', null, `${e.item.structure} ${e.item.id}`));
          d.appendChild(el('span', null, vals.map(([k, v]) => `${k}: ${v}`).join(' · ') || 'no values'));
          more.appendChild(d);
        });
        card.appendChild(more);
        const why = el('input'); why.placeholder = 'Why not (optional)'; why.autocomplete = 'off';
        const row = el('div', 'fpl-row');
        const decide = ok => async () => {
          row.querySelectorAll('button').forEach(x => { x.disabled = true; });
          try {
            await FP.approvals.decide(a.id, ok, ok ? '' : why.value.trim());
            say(ok ? `${a.title} from ${a.userName || 'someone'} is approved and saved.` : `${a.title} from ${a.userName || 'someone'} is not approved: nothing was saved.`, 'info');
          } catch (e) { say(e.message); }
          await paintHome();
        };
        row.append(button('Approve', 'primary', decide(true)), button('Not approved', null, decide(false)), why);
        card.appendChild(row);
        box.appendChild(card);
      });
      return box;
    }
    /* A supervisor on a form: a note when something waits for them. */
    async function approvalsNote() {
      if (oneForm && !(await FP.users.can('supervisor'))) return;
      if (!(await FP.users.can('supervisor'))) return;
      const n = (await FP.approvals.list(FP.identity.site).catch(() => [])).length;
      if (!n || notice.children.length) return;
      say(`${n} waiting for your approval.`, 'info', oneForm ? null : button('See them', null, () => goHome()));
    }

    /* This terminal's ID and site (admins): kept on this machine. */
    function terminalPart() {
      const box = el('details', 'fpl-card quiet fpl-this');
      box.appendChild(el('summary', null, `This terminal: ${FP.identity.terminalId} at ${FP.identity.site}`));
      const row = el('div', 'fpl-row');
      const ss = el('select');
      FP.sites.list().then(sites => sites.filter(x => x.active).forEach(x => { const o = el('option', null, `${x.name} (${x.id})`); o.value = x.id; o.selected = x.id === FP.identity.site; ss.appendChild(o); })).catch(() => {});
      row.append(ss, button('Move it to this site', null, async () => {
        if (!ss.value || ss.value === FP.identity.site) return;
        if (!confirm(`Move ${FP.identity.terminalId} to ${ss.value}? It takes that site's forms from now on and leaves its group; what it saved keeps its old site.`)) return;
        try { if (place.group) await FP.groups.leave(FP.identity.terminalId); await FP.sites.assign(ss.value); location.reload(); } catch (e) { say(e.message); }
      }));
      row.appendChild(button('Change its ID…', null, async () => {
        if (!confirm(`Change ${FP.identity.terminalId}'s ID? What it already saved keeps ${FP.identity.terminalId}; its group and forms stay with the old ID.`)) return;
        await FP.startup.reassign({ title: 'Launcher' }); location.reload();
      }));
      box.appendChild(row);
      return box;
    }

    // A newer version was published: a launcher following latest reloads it (after the record is saved, if needed).
    let pendingReload = false;
    window.addEventListener('fp-defs', () => {
      if (!formId) { if (inst === null && FP.users) loadPlace().then(() => { if (!formId) paintHome(); }).catch(() => {}); return; }
      if (pinned != null) { if (inst) FP.defs.version('form', formId, pinned).then(d => d && pinNotes(d)).catch(() => {}); return; }
      const doc = FP.defs.get('form', formId);
      if (doc && !inst) { openForm(); return; }
      if (!doc || !inst || doc.version === inst.version) return;
      if (!inst.isDirty()) { openForm(); return; }
      if (pendingReload) return;
      pendingReload = true;
      const b = button('Load it now (unsaved values are kept as a draft)');
      b.onclick = () => { pendingReload = false; openForm(); };
      say(`A new version of this form (v${doc.version}) was published.`, null, b);
    });
    window.addEventListener('fp-outbox', e => showOutbox(e.detail));
    homeBtn.onclick = () => goHome();

    // Print: the record on screen, or a blank form; with everything linked when the form opens others.
    printBtn.onclick = e => {
      e.stopPropagation();
      const old = document.querySelector('.fpl-menu');
      if (old) { old.remove(); return; }
      const m = el('div', 'fpl-menu');
      const item = (label, note, mode, tree) => {
        const b = el('button', null, label);
        b.appendChild(el('small', null, note));
        b.onclick = () => { m.remove(); if (inst) inst.print(mode, { tree }).catch(err => window.__fpReport('Print failed: ' + err.message)); };
        m.appendChild(b);
      };
      const tree = inst && inst.hasTree();
      item('Print this record', 'What is on the screen now', 'record', false);
      if (tree) item('Print this record with everything linked', 'Forms open over it and records linked to it, each on its own page', 'record', true);
      item('Print a blank form', 'For filling in by hand', 'blank', false);
      if (tree) item('Print a blank form with all its sub-forms', 'Every form it can open, each on its own page', 'blank', true);
      const r = printBtn.getBoundingClientRect();
      m.style.top = (r.bottom + 6) + 'px';
      m.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
      document.body.appendChild(m);
      setTimeout(() => document.addEventListener('click', () => m.remove(), { once: true }), 0);
    };

    // Whoever signs in decides what shows: home again, or the form if they may use it.
    async function afterSignIn() { await showUser(); await loadPlace(); if (formId) await openForm(); else await paintHome(); }
    async function signInAgain() { await FP.users.gate({ title: titleText }); await afterSignIn(); }
    who.onclick = async () => {
      if (inst && inst.isDirty() && !confirm('Switch user? The values typed so far stay on this terminal as a draft.')) return;
      await FP.users.signOut('switched');
      await signInAgain();
    };

    FP.launcher.current = () => inst;   // the form on screen (for the update check and for testing)
    return FP.startup.run({ title: 'Form' }).then(async ready => {
      term.textContent = `${ready.terminalId} · ${ready.site}`;
      await FP.defs.load();
      await loadPlace();
      if (formId) setTitle(formTitle(formId)); else setTitle(place.group ? place.group.name : 'Forms');
      await FP.users.gate({ title: formId ? formTitle(formId) : `Sign in at ${ready.terminalId}` });
      await showUser();
      showOutbox();
      FP.defs.watch();
      FP.users.watchIdle(15, () => signInAgain());
      if (FP.users.watchSignIn) FP.users.watchSignIn(async u => { if (!u) await signInAgain(); else await afterSignIn(); });
      if (formId) await openForm(); else await goHome();
      // A new release of the platform: reload onto it once nothing unsaved is on screen.
      if (FP.updates) FP.updates.watch({
        isSafe: () => !inst || (!inst.isDirty() && !(inst.waiting && inst.waiting().length) && FP.outbox.status().state !== 'writing'),
        onReady: (v, newer) => say(`${newer ? 'An update' : 'A change of version'} (${v}) is ready. This page reloads by itself as soon as nothing unsaved is on screen.`, 'info'),
      });
      return { instance: () => inst, home: () => goHome(), open: id => pick(id) };
    }).catch(e => window.__fpReport('Startup failed: ' + (e.message || e)));
  }

  /* ---------- Launcher files ---------- */
  const escHtml = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const FILE_RE = /^[a-z][a-z0-9-]{0,60}\.html$/;

  /* The text of a launcher file for a form; version 'latest' or a number. */
  function html(formId, opts) {
    opts = opts || {};
    const doc = opts.doc || FP.defs.get('form', formId);
    const title = opts.title || (doc && doc.def.title) || formId;
    const launch = { form: formId, version: opts.version == null ? 'latest' : opts.version, made: new Date().toISOString(), by: opts.by || null, runtime: VERSION, boot: 1 };
    return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escHtml(title)}</title>
<!-- Launcher for form ${escHtml(formId)}, made by the Form Platform. Make it again from the test page or the editor rather than editing it. -->
<script>
${preamble('Check the runtime folder (next to this launchers folder) has finished syncing.')}
</script>
<script>window.FP_LAUNCH = ${JSON.stringify(launch)}; window.FP_PAGE = 'launcher';</script>
</head>
<body>
<script src="../runtime/releases.js"></script>
<script src="../runtime/boot.js"></script>
<script>if (!window.__fpBootRetrying && window.FP && FP.launcher) FP.launcher.start();</script>
</body>
</html>
`;
  }

  /* launch.html, at the top of the data folder: the one launcher every terminal opens (0.41). */
  function homeHtml() {
    return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forms</title>
<!-- The launcher every terminal opens: its home screen shows the forms of the terminal and who signs in.
     Written by the Form Platform when a release is installed; don't edit. -->
<script>
${preamble('Check the runtime folder (next to this file) has finished syncing.')}
</script>
<script>window.FP_PAGE = 'launcher';</script>
</head>
<body>
<script src="runtime/releases.js"></script>
<script src="runtime/boot.js"></script>
<script>if (!window.__fpBootRetrying && window.FP && FP.launcher) FP.launcher.start();</script>
</body>
</html>
`;
  }

  const fileNameFor = (formId, version) => `${formId}${version == null || version === 'latest' ? '' : '-v' + version}.html`;

  async function requirePublisher() {
    if (FP.users && !(await FP.users.can(FP.defs.publishRole))) throw new Error('Only a publisher or an admin can make launcher files.');
  }

  /* What a launcher file says, read back: { name, form, version, made, by, runtime }. */
  function parse(name, text) {
    const m = /window\.FP_LAUNCH = (\{[^\n]*\});/.exec(text || '');
    let launch = null;
    try { launch = m ? JSON.parse(m[1]) : null; } catch (_) { launch = null; }
    return Object.assign({ name }, launch || { form: null });
  }

  FP.launchers = {
    KERNEL,
    VERSION,
    preamble,
    html,
    homeHtml,
    fileNameFor,
    /* Write launch.html at the top of the data folder. */
    async makeHome() {
      await requirePublisher();
      await FP.files.writeText([], 'launch.html', homeHtml());
      return 'launch.html';
    },

    /* Write launchers/{form}.html (latest) or launchers/{form}-v{n}.html (pinned). */
    async make(formId, opts) {
      opts = opts || {};
      await requirePublisher();
      const doc = FP.defs.get('form', formId);
      if (!doc || doc.retired) throw new Error(`No published form named ${formId}.`);
      if (!doc.def.launchable) throw new Error(`Form ${formId} isn't launchable. Set launchable: true on it first.`);
      const version = opts.version == null || opts.version === 'latest' ? 'latest' : Number(opts.version);
      let pinnedDoc = null;
      if (version !== 'latest') {
        pinnedDoc = await FP.defs.version('form', formId, version);
        if (!pinnedDoc) throw new Error(`Form ${formId} has no version ${version}.`);
      }
      const name = opts.name || fileNameFor(formId, version);
      if (!FILE_RE.test(name)) throw new Error('A launcher file name uses lowercase letters, digits and -, and ends in .html.');
      const user = FP.users ? await FP.users.current() : null;
      await FP.files.writeText(LAUNCHERS, name, html(formId, { version, doc: pinnedDoc, by: user ? user.name : null }));
      return name;
    },

    /* Launcher files in the data folder, with what each says and whether its form is still there. */
    async list() {
      const names = (await FP.files.list(LAUNCHERS)).filter(n => n.endsWith('.html'));
      const out = [];
      for (const n of names) {
        const info = parse(n, await FP.files.readText(LAUNCHERS, n));
        const doc = info.form ? FP.defs.get('form', info.form) : null;
        info.problem = !info.form ? 'not a launcher made by the platform'
          : !doc ? `form ${info.form} is not published`
          : doc.retired ? `form ${info.form} is retired`
          : !doc.def.launchable ? `form ${info.form} is no longer launchable`
          : !info.boot ? 'made before updates could be installed from the app; make it again'
          : null;
        out.push(info);
      }
      return out;
    },

    async remove(name) {
      await requirePublisher();
      if (!FILE_RE.test(name)) throw new Error('Not a launcher file name.');
      return FP.files.remove(LAUNCHERS, name);
    },
  };

  FP.launcher = { start };

  /* Registered last, so a module that failed partway never reports as loaded. */
  (window.FP.modules = window.FP.modules || {})['fp-launcher'] = '0.42.0';
})();
