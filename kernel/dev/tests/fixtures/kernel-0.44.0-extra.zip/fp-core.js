/* Form Platform kernel: core (steps 1–7)
 * Namespace, a small IndexedDB key-value store, data-folder access,
 * and JSON Lines append/read.
 *
 * Classic script on purpose: Edge and Chrome block ES modules
 * (<script type="module">) on pages opened from file://.
 */
(function () {
  'use strict';

  const FP = (window.FP = window.FP || {});
  FP.version = '0.44.0';

  /* ---------- Locks ----------
   * Web Locks serialize across every tab on the device. Where they are missing,
   * fall back to an in-page queue so at least this page never races itself.
   */
  const localChains = new Map();
  FP.lock = function (name, fn) {
    if (navigator.locks && navigator.locks.request) return navigator.locks.request(name, fn);
    const prev = localChains.get(name) || Promise.resolve();
    const run = prev.then(() => fn(), () => fn());
    localChains.set(name, run.catch(() => {}));
    return run;
  };
  FP.lock.crossTab = !!(navigator.locks && navigator.locks.request);

  /* ---------- IndexedDB on this device ----------
   * kv:     small settings (data-folder handle, terminal ID, open contexts).
   * outbox: events saved on this device but not yet written to the data folder.
   * Both survive reloads and browser restarts.
   */
  const DB_NAME = 'fp-kernel';
  const DB_VERSION = 2;

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
        if (!db.objectStoreNames.contains('outbox')) db.createObjectStore('outbox', { autoIncrement: true });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error('Close other tabs of this app once to finish updating local storage, then reload.'));
    });
  }

  /* Run fn(objectStore) in one transaction; resolves with fn's result once the
   * transaction commits (a request's .result, or a plain value). */
  async function withStore(store, mode, fn) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, mode);
      const out = fn(tx.objectStore(store));
      tx.oncomplete = () => { db.close(); resolve(out instanceof IDBRequest ? out.result : out); };
      tx.onerror = () => { db.close(); reject(tx.error); };
      tx.onabort = () => { db.close(); reject(tx.error || new Error('Local storage transaction aborted')); };
    });
  }

  FP.kv = {
    get: key => withStore('kv', 'readonly', s => s.get(key)),
    set: (key, value) => withStore('kv', 'readwrite', s => s.put(value, key)),
    del: key => withStore('kv', 'readwrite', s => s.delete(key)),
  };

  /* Raw outbox storage; the writer in fp-event.js decides when to flush. */
  FP.outboxStore = {
    /* Adds all items in one transaction: all are saved or none are. */
    addMany: items => withStore('outbox', 'readwrite', s => { items.forEach(i => s.add(i)); return items.length; }),
    /* [{ key, value }] in the order they were added. */
    all: () => withStore('outbox', 'readonly', s => {
      const rows = [];
      s.openCursor().onsuccess = e => { const c = e.target.result; if (c) { rows.push({ key: c.key, value: c.value }); c.continue(); } };
      return rows;
    }),
    remove: keys => withStore('outbox', 'readwrite', s => { keys.forEach(k => s.delete(k)); return keys.length; }),
    count: () => withStore('outbox', 'readonly', s => s.count()),
  };

  /* ---------- Data folder access ----------
   * The user picks the data folder once (a OneDrive-synced folder today,
   * possibly a mapped drive later). The handle is stored in IndexedDB.
   * connect() and reauthorize() must be called from a click or tap.
   */
  FP.folder = {
    supported: typeof window.showDirectoryPicker === 'function',
    handle: null,

    async connect() {
      const h = await window.showDirectoryPicker({ id: 'fp-data', mode: 'readwrite' });
      await FP.kv.set('dataFolder', h);
      FP.folder.handle = h;
      return h;
    },

    /* Returns 'none' | 'granted' | 'prompt' | 'denied' without prompting. */
    async restore() {
      const h = await FP.kv.get('dataFolder');
      if (!h) return 'none';
      FP.folder.handle = h;
      return h.queryPermission({ mode: 'readwrite' });
    },

    async reauthorize() {
      if (!FP.folder.handle) throw new Error('No data folder connected yet.');
      return FP.folder.handle.requestPermission({ mode: 'readwrite' });
    },

    async forget() {
      await FP.kv.del('dataFolder');
      FP.folder.handle = null;
    },

    /* Walk (and optionally create) subfolders, e.g. ['data', 'qc-line', '2026-11-10']. */
    async dir(parts, create) {
      if (!FP.folder.handle) throw new Error('No data folder connected.');
      let d = FP.folder.handle;
      for (const part of parts) d = await d.getDirectoryHandle(part, { create: !!create });
      return d;
    },
  };

  /* ---------- JSON Lines files ----------
   * One record per line. Appends never rewrite earlier lines in place,
   * and a half-written last line (crash, sync mid-upload) is skipped on read.
   */
  /* Serialize writes to one file across every tab and launcher on this device.
   * Two pages writing the same file at once would otherwise each copy the
   * file, append, and commit, and the second commit would drop the first line.
   * (Across devices, unique terminal IDs already guarantee one writer per file.)
   */
  function withFileLock(parts, fileName, fn) {
    return FP.lock('fp-file:' + parts.concat(fileName).join('/'), fn);
  }

  async function commit(fh, keepExisting, writeFn) {
    // Writes go to a temporary swap file; the real file only changes on close().
    const w = await fh.createWritable({ keepExistingData: keepExisting });
    try {
      await writeFn(w);
      await w.close();
    } catch (err) {
      try { await w.abort(); } catch (_) { /* already closed */ }
      throw err;
    }
  }

  /* Appends that arrive while a file is busy are batched into the next commit,
   * so a burst costs one or two file copies instead of one per record. */
  const queues = new Map();

  async function flush(key, q) {
    q.running = true;
    try {
      while (q.items.length) {
        const batch = q.items.splice(0);
        try {
          await withFileLock(q.parts, q.fileName, async () => {
            const d = await FP.folder.dir(q.parts, true);
            const fh = await d.getFileHandle(q.fileName, { create: true });
            const size = (await fh.getFile()).size;
            await commit(fh, true, async w => {
              await w.seek(size);
              await w.write(batch.map(b => b.line).join(''));
            });
          });
          batch.forEach(b => b.resolve());
        } catch (err) {
          batch.forEach(b => b.reject(err));
        }
      }
    } finally {
      q.running = false;
      queues.delete(key);
    }
  }

  FP.files = {
    appendLine(parts, fileName, obj) {
      const key = parts.concat(fileName).join('/');
      let q = queues.get(key);
      if (!q) { q = { parts: parts.slice(), fileName, items: [], running: false }; queues.set(key, q); }
      return new Promise((resolve, reject) => {
        q.items.push({ line: JSON.stringify(obj) + '\n', resolve, reject });
        if (!q.running) flush(key, q);
      });
    },

    /* Replace a whole JSON file (registry entries, definitions, checkpoints).
     * compact: no indentation, for big machine-read files like checkpoints. */
    async writeJson(parts, fileName, obj, compact) {
      return withFileLock(parts, fileName, async () => {
        const d = await FP.folder.dir(parts, true);
        const fh = await d.getFileHandle(fileName, { create: true });
        await commit(fh, false, w => w.write(compact ? JSON.stringify(obj) : JSON.stringify(obj, null, 2)));
      });
    },

    /* Replace a whole text file (a launcher page, a copied runtime file). */
    async writeText(parts, fileName, text) {
      return withFileLock(parts, fileName, async () => {
        const d = await FP.folder.dir(parts, true);
        const fh = await d.getFileHandle(fileName, { create: true });
        await commit(fh, false, w => w.write(text));
      });
    },

    /* Read a whole text file. Missing = null. */
    async readText(parts, fileName) {
      try {
        const d = await FP.folder.dir(parts, false);
        const fh = await d.getFileHandle(fileName);
        return await (await fh.getFile()).text();
      } catch (err) {
        if (err && err.name === 'NotFoundError') return null;
        throw err;
      }
    },

    /* Read a whole JSON file. Missing or unreadable = null. */
    async readJson(parts, fileName) {
      try {
        const d = await FP.folder.dir(parts, false);
        const fh = await d.getFileHandle(fileName);
        return JSON.parse(await (await fh.getFile()).text());
      } catch (err) {
        if (err && (err.name === 'NotFoundError' || err instanceof SyntaxError)) return null;
        throw err;
      }
    },

    /* Returns { records, bad } — bad = lines that failed to parse. Missing file = empty. */
    async readLines(parts, fileName) {
      let fh;
      try {
        const d = await FP.folder.dir(parts, false);
        fh = await d.getFileHandle(fileName);
      } catch (err) {
        if (err && err.name === 'NotFoundError') return { records: [], bad: 0 };
        throw err;
      }
      const text = await (await fh.getFile()).text();
      const records = [];
      let bad = 0;
      for (const line of text.split('\n')) {
        if (!line.trim()) continue;
        try { records.push(JSON.parse(line)); } catch (_) { bad++; }
      }
      return { records, bad };
    },

    /* Delete a file; missing = false. */
    async remove(parts, fileName) {
      try {
        const d = await FP.folder.dir(parts, false);
        await d.removeEntry(fileName);
        return true;
      } catch (err) {
        if (err && err.name === 'NotFoundError') return false;
        throw err;
      }
    },

    /* File names in a folder; missing folder = empty list. */
    async list(parts) {
      let d;
      try { d = await FP.folder.dir(parts, false); }
      catch (err) {
        if (err && err.name === 'NotFoundError') return [];
        throw err;
      }
      const names = [];
      for await (const [name, h] of d.entries()) if (h.kind === 'file') names.push(name);
      return names.sort();
    },

    /* Subfolder names; missing folder = empty list. */
    async listDirs(parts) {
      let d;
      try { d = await FP.folder.dir(parts, false); }
      catch (err) {
        if (err && err.name === 'NotFoundError') return [];
        throw err;
      }
      const names = [];
      for await (const [name, h] of d.entries()) if (h.kind === 'directory') names.push(name);
      return names.sort();
    },

    /* A file's size in bytes without reading it; missing file = null. */
    async size(parts, fileName) {
      try {
        const d = await FP.folder.dir(parts, false);
        const fh = await d.getFileHandle(fileName);
        return (await fh.getFile()).size;
      } catch (err) {
        if (err && err.name === 'NotFoundError') return null;
        throw err;
      }
    },

    /* Write a new binary file (a photo, a PDF). Refuses to replace an existing
     * file: stored media is never overwritten. */
    async writeBlob(parts, fileName, blob) {
      return withFileLock(parts, fileName, async () => {
        const d = await FP.folder.dir(parts, true);
        let exists = true;
        try { await d.getFileHandle(fileName); } catch (err) { if (err && err.name === 'NotFoundError') exists = false; else throw err; }
        if (exists) throw new Error(`${parts.concat(fileName).join('/')} already exists; stored files are never replaced.`);
        const fh = await d.getFileHandle(fileName, { create: true });
        await commit(fh, false, w => w.write(blob));
      });
    },

    /* Write JSON compressed with the browser's built-in gzip (no library) as
     * `${baseName}.gz`; where gzip isn't available, plain compact JSON as baseName.
     * Returns the name written. For big files written once (closed months). */
    async writeJsonGz(parts, baseName, obj) {
      if (typeof CompressionStream !== 'function') { await FP.files.writeJson(parts, baseName, obj, true); return baseName; }
      const blob = await new Response(new Blob([JSON.stringify(obj)]).stream().pipeThrough(new CompressionStream('gzip'))).blob();
      const name = baseName + '.gz';
      await withFileLock(parts, name, async () => {
        const d = await FP.folder.dir(parts, true);
        const fh = await d.getFileHandle(name, { create: true });
        await commit(fh, false, w => w.write(blob));
      });
      return name;
    },

    /* Read JSON written by writeJson or writeJsonGz (.gz names are unzipped); missing or damaged = null. */
    async readJsonAny(parts, fileName) {
      if (!fileName.endsWith('.gz')) return FP.files.readJson(parts, fileName);
      const f = await FP.files.readFile(parts, fileName);
      if (!f) return null;
      try { return JSON.parse(await new Response(f.stream().pipeThrough(new DecompressionStream('gzip'))).text()); }
      catch (_) { return null; }
    },

    /* A file as a File object (size and type without reading it all); missing = null. */
    async readFile(parts, fileName) {
      try {
        const d = await FP.folder.dir(parts, false);
        return await (await d.getFileHandle(fileName)).getFile();
      } catch (err) {
        if (err && err.name === 'NotFoundError') return null;
        throw err;
      }
    },

    /* A whole file as text; missing file = null. */
    async readText(parts, fileName) {
      try {
        const d = await FP.folder.dir(parts, false);
        const fh = await d.getFileHandle(fileName);
        return await (await fh.getFile()).text();
      } catch (err) {
        if (err && err.name === 'NotFoundError') return null;
        throw err;
      }
    },
  };

  /* ---------- Small helpers ---------- */
  FP.util = {
    localDate(d = new Date()) {
      const p = n => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
    },
    env() {
      return {
        url: location.protocol,
        secureContext: window.isSecureContext,
        folderAccess: FP.folder.supported,
        userAgent: navigator.userAgent,
      };
    },
  };

  /* Registered last, so a module that failed partway never reports as loaded. */
  (window.FP.modules = window.FP.modules || {})['fp-core'] = '0.44.0';
})();
