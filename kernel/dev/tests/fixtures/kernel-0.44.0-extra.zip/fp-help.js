/* Form Platform: Help in the editor (step 28).
 * Load after fp-script.js.
 *
 * A reference made from the platform itself, so it can't drift from what the editor does:
 *   - The script on one page: the rules, then every keyword per kind (from FP.script's own tables).
 *   - Fields: every control in the catalog with its settings (FP.forms.controls()).
 *   - Form settings (FP.forms.formSettings()).
 *   - Formulas: every built-in with what goes in its brackets, what it gives and an example (FP.fn.help),
 *     then the functions in this library.
 *   - What publish checks.
 * Shown in the editor (? Help in the bar), searchable, and saved as one HTML page to print or share.
 */
(function () {
  'use strict';

  const FP = window.FP;
  if (!FP || !FP.editor || !FP.script) throw new Error('Load fp-script.js before fp-help.js');
  const { el, btn, input } = FP.editor.ui;

  const esc = t => String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const TYPE_TEXT = { text: 'text', name: 'a name (letters, digits, _)', number: 'a number', integer: 'a whole number', boolean: 'yes or no', choice: 'one of a list', formula: 'a formula', texts: 'a list of words', target: 'source.value', list: 'a list', map: 'names and values', any: 'see the note', control: 'a kind of field', form: 'a form\'s name', options: 'a list of options' };

  /* ---------- The chapters, as plain data ---------- */
  function scriptChapter() {
    return {
      id: 'script', title: 'The script on one page',
      intro: 'Every definition can be read and written as text. The script and the map edit the same thing: switch with { } beside the title.',
      blocks: [
        { h: 'The rules', list: [
          'One line, one statement. A line starts with what it is: form, source, field, layout, row, button…',
          'What belongs to a line is indented under it, two spaces a level.',
          'Text with spaces goes in "quotes". A quote inside text is \\" ; a new line is \\n.',
          'A formula starts with = and runs to the end of the line: = InSpec(measuredOD, spec.min, spec.max)',
          'yes and no are true and false; none is nothing.',
          '# starts a comment. Comments are kept with the definition.',
          'Leave out what you don\'t need: everything has a default.',
          'A setting with no line of its own is its name and its value: unit in, decimals 3.',
          'A list is the name and the words: options L01 L02 L05. An empty list: options list.',
          'A setting with parts is its name with the parts indented under it (values, limits, prefill).',
          'Tab offers what can come next. F8 goes to the next problem. Tidy puts it in the standard order.',
        ] },
        { h: 'A form', code: 'form od-check "OD check"\n  sites all\n  launchable yes\n\n  source odCheck item\n    structure od-checks\n    id new OD\n    values\n      measuredOD write\n\n  field measuredOD number "Measured OD" required\n    unit in\n    saves odCheck.measuredOD\n  field result value Result\n    = IF(measuredOD > 1.3, "Fail", "Pass")\n\n  layout\n    row measuredOD 6  result 6\n\n  button save Save\n    save' },
        { h: 'Lines of a form', table: [
          ['form NAME "Title"', 'The first line: what it is and its name (the name never changes).'],
          ['sites all  |  sites ABI ELP', 'Where it is used.'],
          ['launchable yes', 'It gets its own launcher file.'],
          ['source NAME item', 'One item of a structure. Under it: structure, id, values.'],
          ['source NAME items', 'A list of items. Under it: structure, filter = …, values.'],
          ['source NAME value = formula', 'A worked-out value, read by name.'],
          ['id field F  |  id fixed X  |  id new [PREFIX]  |  id where = rule', 'Which item (under an item source).'],
          ['values  (then NAME read|write|both)', 'What the form reads from and saves to the source.'],
          ['read NAME', 'Something to read before starting. Under it: label, show media|text, where (then TAG = formula), text, statement, every.'],
          ['media PATH "Title"', 'A file from the media folder this form uses (0.42), e.g. media "setup-sheets/D-1047 Rev B.pdf". Under it: tag NAME VALUE … (tag die D-1047).'],
          ['where  (then TAG = formula)', 'Under a media field or a read: only the form\'s media tagged so, e.g. die = dieNo. None: every file on the list.'],
          ['field NAME KIND "Label" [required]', 'A field. KIND is a kind of field (see Fields).'],
          ['= formula', 'Under a field, a worked-out value (value, badge, chart…).'],
          ['saves SOURCE.VALUE', 'Under a field, where it saves. A list source: every item gets it.'],
          ['column NAME', 'Under a table, a column. Under it: label, control, edit yes, options…'],
          ['layout', 'Then row, section "Title", panels (panel "Title", width narrow|third|half), tabs (tab "Title"), steps (step "Title").'],
          ['row NAME M  NAME 6  NAME pc:4 tablet:6 phone:12', 'Fields side by side, each with its size (S, M, L, Full) or width out of 12.'],
          ['button NAME "Label"', 'Then save [tree|form], subform NAME (opens a sub-form), when =; older: open FORM, link, prefill, apply.'],
          ['subform NAME "Label"', 'A sub-form (0.40). Under it: title = formula, repeat count N | repeat count = … | repeat list = … | repeat open, saves own, required yes, link SOURCE, back FIELD ITS_FIELD [how], then its own source, field and layout lines.'],
          ['print', 'Printing: page, orientation, signatures "Checked by" …, layout.'],
        ] },
        { h: 'Lines of a structure', table: [
          ['structure NAME "Label"', 'The first line.'],
          ['id "What it is called" entered  |  id "Delivery no." new DEL', 'The item ID: entered on the form, or made new each save with a prefix.'],
          ['container NAME [rule] [from OTHER]', 'A value forms save to; rule: latest, first, sum, count, average, min, max, list.'],
          ['calculated NAME FUNCTION', 'Worked out by a library function; its inputs indented under it (start $firstAt).'],
          ['status VALUE = rule', 'Status rules, checked from the top; the first true one names the item.'],
          ['live DAYS  |  open = rule', 'Loading: only recent items, plus those still open.'],
        ] },
        { h: 'Lines of a function', table: [
          ['function NAME "Label"', 'The first line.'],
          ['input NAME TYPE [optional]', 'Each input in order; TYPE is text, number, date, boolean, list, record, item or any.'],
          ['= formula', 'What it works out from its inputs.'],
          ['gives TYPE', 'What it gives.'],
          ['kind lookup  +  reads', 'A lookup: under reads, structure, from items|entries, match VALUE INPUT, match VALUE value X, return, summary, window.'],
        ] },
        { h: 'Media (0.42)', list: [
          'Media is plain files in the data folder\'s media folder. A form lists the ones it uses (Media on its map), each with tags of your own (die: D-1047; kind: setup sheet).',
          'A Media field and Read first show the files of that list whose tags match: die = dieNo shows the files tagged die = the Die no. field. A tag value all matches anything.',
          'Read first asks again when the file changes (its modified time).',
          'Signatures (drawing pads) save into media/signatures, photos into media/photos, other files into media/files, named form_record_field_person_date-time, so a report can find them by that. The field saves the file\'s path.',
        ] },
      ],
    };
  }

  function fieldsChapter() {
    const all = FP.forms.controls();
    const cats = [['entry', 'Fields people fill in'], ['display', 'Fields that show something'], ['visual', 'Charts and visuals']];
    return {
      id: 'fields', title: 'Fields',
      intro: 'Every kind of field and its settings, from the control catalog. Settings marked * are required.',
      blocks: cats.map(([cat, h]) => ({ h, items: all.filter(c => (c.category === cat) || (cat === 'display' && !['entry', 'visual'].includes(c.category))).map(c => ({
        name: c.name, title: c.label || c.name, text: c.help || '',
        rows: (c.settings || []).filter(s => !['name', 'control'].includes(s.name)).map(s => [s.name + (s.required ? ' *' : ''), [s.label, s.help, s.options ? `one of: ${s.options.join(', ')}` : TYPE_TEXT[s.type] || s.type].filter(Boolean).join(' · ')]),
      })) })),
    };
  }

  function formChapter() {
    return {
      id: 'form', title: 'Form settings',
      intro: 'The settings of a form itself (the first row of its map).',
      blocks: [{ table: FP.forms.formSettings().filter(s => !['fields', 'comments', 'lists'].includes(s.name)).map(s => [s.name + (s.required ? ' *' : ''), [s.label, s.help].filter(Boolean).join(' · ')]) }],
    };
  }

  function subformsChapter() {
    return {
      id: 'subforms', title: 'Sub-forms',
      intro: 'A sub-form is a form inside a form, opened by a button (0.40). It has its own fields and sources, reads the master form\'s fields and sources by name, and sends values back to it. It replaces opening another published form.',
      blocks: [
        { h: 'Its settings (its row on the master form\'s map)', table: [
          ['Label, Named by', 'What people see; Named by is a formula, e.g. "Re-test for " & dieNo, shown on its screen and its button.'],
          ['Opened by', 'The buttons that open it (What it does: Open a sub-form).'],
          ['How many times', 'Once; a set number; a number a formula works out; once for each item of a list (each is the item, index its number); or as many as needed (Save and add another, then Finish).'],
          ['Its records are saved', 'With this form (default): they wait with it and are saved in its save, all or nothing. On their own: its Save saves at once, and they point at this form\'s record, whose ID is set aside for it.'],
          ['Its records point at', 'Which of this form\'s items (the first one it saves, unless you pick another).'],
          ['Required', 'This form can\'t be saved until it is done (every run, when it repeats; a run skipped because someone else saw to it counts).'],
          ['Sends back', 'A field here ← its field; when it repeats, what to do with the several values: the first, the last, the average, the lowest, the highest, the total, how many, all joined, or all of them into a field that holds several.'],
        ] },
        { h: 'On the terminal', list: [
          'Its button says how far it has got: Done, Saved, 3 of 5 done, 2 done.',
          'It opens over the form, with ‹ Back. Back leaves the run it is on; the ones done stay done.',
          'Going through a list: the list is taken when it opens. When a run\'s item was changed on another terminal meanwhile, that run says so, with Skip it or Add mine anyway.',
          'A record saved on its own while the master form is never saved is listed in Admin › Clean-up.',
        ] },
        { h: 'Changed since you opened it', list: [
          'Every form (0.40): saving an item someone else changed after the form read it asks first. Keep theirs puts their values back on screen; Save mine over it saves; See both shows the two side by side.',
        ] },
      ],
    };
  }

  function placesChapter() {
    return {
      id: 'places', title: 'The map, terminals and roles',
      intro: 'The editor\'s map (0.41) is every site with its terminal groups and terminals, each with its forms, and each form with what it uses. People sit above the sites, for admins.',
      blocks: [
        { h: 'Roles, each including the one before', table: [
          ['User', 'Fills in the forms of the terminal they are at.'],
          ['Supervisor', 'Fills in any form at the site; approves what waits for approval.'],
          ['Publisher', 'Makes and publishes forms, structures and functions, and their media; sets which forms each group and terminal has.'],
          ['Admin', 'Everything: people and roles, sites, updates, records, clean-up.'],
        ] },
        { h: 'Terminal groups and terminals', list: [
          'A group is terminals at one site that run the same forms, e.g. Production presses: T01–T05. A terminal is in one group at most.',
          'A terminal taken out of its group keeps a copy of the group\'s forms; one in no group has its own list.',
          'Users see the forms of their terminal\'s group (or its own list), in that order. Supervisors and up see those, then every form at the site.',
          'A terminal with no forms yet: users see "No forms yet: ask a supervisor". Until a site has any group or terminal list, everyone there sees every form.',
          'A form opened some other way (a one-form launcher file, an address) follows the same rules, and offers to sign in as someone who can.',
        ] },
        { h: 'The launcher', list: [
          'launch.html, at the top of the data folder, is the one launcher every terminal opens. It knows which terminal it is; whoever signs in decides what its home screen shows.',
          'Publishers and admins get an Editor button. The editor is always the terminal Editor, on any computer, and works on every site.',
        ] },
        { h: 'Approvals', list: [
          'A form with "Needs a supervisor\'s approval" doesn\'t save what a user fills in: it waits, unsaved, until a supervisor approves it.',
          'A supervisor opening the launcher sees what waits first: Approve saves it as it was filled in (with who approved it); Not approved saves nothing.',
          'A supervisor\'s own saves on such a form are saved straight away.',
        ] },
      ],
    };
  }

  function formulasChapter() {
    const names = (FP.fn.HELP_NAMES || []).slice();
    const lib = FP.fn.list().filter(f => !/^ZzTry/.test(f.name)).sort((a, b) => a.name.localeCompare(b.name));
    return {
      id: 'formulas', title: 'Formulas',
      intro: 'A formula is like a spreadsheet formula: names of fields and sources, numbers, "text", + - * / ^, & to join text, = <> < > <= >= to compare, and functions. AND, OR and NOT are functions: AND(a, b). source.value reads a value; a list\'s .value gives every item\'s value as a list; list["ID"] picks one item. In FILTER, EACH and SORT, item is each item in turn.',
      blocks: [
        { h: 'Built in', items: names.map(n => { const h = FP.fn.help(n); return { name: n, title: `${n}(${h.args.join(', ')})`, text: h.text, example: h.example }; }) },
        { h: 'In this library', items: lib.length ? lib.map(f => { const h = FP.fn.help(f.name) || { args: [] }; return { name: f.name, title: `${f.name}(${h.args.join(', ')})`, text: [f.label && f.label !== f.name ? f.label : null, f.kind === 'lookup' ? `reads ${(f.reads || {}).structure}` : null, f.output && f.output !== 'any' ? `gives ${f.output}` : null].filter(Boolean).join(' · '), example: f.formula ? `= ${f.formula}` : null }; }) : [{ name: '-', title: 'None yet', text: '+ Add > A function makes one.' }] },
      ],
    };
  }

  function checksChapter() {
    return {
      id: 'checks', title: 'What publish checks',
      intro: 'Every definition is checked as you edit, with the same checks publish runs. Nothing with a problem can be published; each problem is marked ✗ on its row of the map, or its line of the script.',
      blocks: [
        { h: 'Every definition', list: ['Its sites are named, and exist.', 'Whatever it uses (a structure, a function, a form it opens) is used at all of its sites.', 'Whatever uses it still covers all of its sites.', 'It is the version you opened: if someone published since, reload first.'] },
        { h: 'Forms', list: ['Every field has a name (letters, digits, _), used once, and a kind of field that exists; every setting is one that kind has, of the right type.',
          'Formulas read without errors, call functions that exist with the right number of inputs, and name only fields and sources of this form (item inside FILTER, EACH and SORT).',
          'A field saves to a source of this form, to a value ticked write on it; nothing saves to a value a structure works out itself.',
          'Two fields don\'t save to one value unless each has a shown-when.',
          'An item\'s ID comes from somewhere: a field (made required), a fixed ID, made new each save, or found by a rule; and the form follows its structure\'s ID rule.',
          'A table with a row per item takes its rows from a list source.',
          'The layout places every required field once, and only fields and buttons that exist.',
          'Buttons: open names a published form; a link names an item the form saves to; scope names a section, tab or step that exists.',
          'Read first: text has text; media needs files on the form\'s media list.',
          'Media: every file has a path in the media folder, is on the list once, not in media/signatures, photos or files, and has tags named with a lowercase letter, then letters and digits.',
          'Sub-forms: a name used once on the form, a button that opens it, no sub-forms inside it; its own fields and sources are checked like a form\'s (they may also read this form\'s fields and sources, and each and index when it repeats).',
          'A value sent back lands in a field people fill in here, from one of its fields, and fits: a number into a number or text, files into files; a sub-form that repeats says what to do with the several values (first, last, average, lowest, highest, total, how many, joined, or all into a field that holds several), and one that doesn\'t says nothing.'] },
        { h: 'Structures', list: ['The ID rule is entered or made new, with a prefix only when made new.', 'Container rules are latest, first, sum, count, average, min, max or list.', 'A calculated value names a function that exists, with each needed input filled from a value or $firstAt, $lastAt, $asOf, $entryCount, $lastAction.', 'No value is both a container and a calculated value, and no form saves to a value the structure works out.', 'Status rules have a status and a formula that reads.', 'No sessions (they were removed in 0.36).'] },
        { h: 'Functions', list: ['The name is letters, digits and _ and isn\'t a built-in.', 'Inputs have names and types; the formula reads with only its inputs, and gives what it says it gives.', 'No loops (a calls b calls a), and no deeper than the nesting limit.', 'A lookup names a structure, matches on its inputs, and gives back a value, several, or the whole item.', 'Functions and structures that use it still work.'] },
      ],
    };
  }

  const chapters = () => [scriptChapter(), fieldsChapter(), formChapter(), subformsChapter(), placesChapter(), formulasChapter(), checksChapter()];

  /* ---------- Drawing ---------- */
  const CSS = `
  .fph{display:grid;grid-template-columns:220px minmax(0,1fr);gap:16px;align-items:start}
  @media (max-width:900px){.fph{grid-template-columns:1fr}}
  .fph-nav{position:sticky;top:52px;display:flex;flex-direction:column;gap:4px}
  .fph-nav button{font:inherit;text-align:left;padding:8px 10px;border:1px solid #e3e7ec;border-radius:8px;background:#fff;cursor:pointer}
  .fph-nav button.on{border-color:#1f5fbf;background:#e8f0fb;font-weight:600}
  .fph-body{min-width:0;font-size:14px;line-height:1.5}
  .fph-body h2{margin:0 0 6px;font-size:20px}
  .fph-body h3{margin:18px 0 6px;font-size:15px;text-transform:uppercase;letter-spacing:.04em;color:#5b6573}
  .fph-body p.intro{color:#3b4552;margin:0 0 10px}
  .fph-body pre{background:#f4f6f8;border:1px solid #e3e7ec;border-radius:8px;padding:10px 12px;font:13px/1.45 Consolas,"Cascadia Mono",monospace;overflow-x:auto}
  .fph-body table{border-collapse:collapse;width:100%;margin:4px 0 8px}
  .fph-body td{border-top:1px solid #eef1f5;padding:5px 8px;vertical-align:top}
  .fph-body td:first-child{font-family:Consolas,"Cascadia Mono",monospace;font-size:13px;white-space:nowrap;color:#1f5fbf;width:1%}
  .fph-item{border:1px solid #e3e7ec;border-radius:8px;padding:8px 12px;margin:0 0 8px;background:#fff}
  .fph-item b{font-family:Consolas,"Cascadia Mono",monospace}
  .fph-item .t{color:#3b4552}
  .fph-item code{display:block;margin-top:4px;color:#5b21b6;font:12px Consolas,monospace;white-space:pre-wrap}
  .fph-item table td:first-child{color:#0b4f5c}
  .fph mark{background:#fff3b0}`;
  function injectCss() { if (document.getElementById('fp-help-css')) return; const s = el('style'); s.id = 'fp-help-css'; s.textContent = CSS; document.head.appendChild(s); }

  const hit = (q, ...parts) => !q || parts.some(x => String(x || '').toLowerCase().includes(q));
  function blockHtml(b, q) {
    let h = '';
    const items = (b.items || []).filter(it => hit(q, it.name, it.title, it.text, it.example, (it.rows || []).map(r => r.join(' ')).join(' ')));
    const table = (b.table || []).filter(r => hit(q, r[0], r[1]));
    const list = (b.list || []).filter(x => hit(q, x));
    const code = b.code && hit(q, b.code) ? b.code : null;
    if (!items.length && !table.length && !list.length && !code) return '';
    if (b.h) h += `<h3>${esc(b.h)}</h3>`;
    if (list.length) h += `<ul>${list.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`;
    if (code) h += `<pre>${esc(code)}</pre>`;
    if (table.length) h += `<table>${table.map(r => `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td></tr>`).join('')}</table>`;
    items.forEach(it => {
      h += `<div class="fph-item"><b>${esc(it.title)}</b>${it.name && it.title !== it.name && !/\(/.test(it.title) ? ` <span class="fpe-hint">${esc(it.name)}</span>` : ''}${it.text ? `<div class="t">${esc(it.text)}</div>` : ''}${it.example ? `<code>${esc(it.example)}</code>` : ''}`
        + (it.rows && it.rows.length ? `<table>${it.rows.map(r => `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td></tr>`).join('')}</table>` : '') + '</div>';
    });
    return h;
  }
  function chapterHtml(c, q) {
    const inner = c.blocks.map(b => blockHtml(b, q)).join('');
    if (q && !inner) return '';
    return `<section id="help-${c.id}"><h2>${esc(c.title)}</h2>${c.intro ? `<p class="intro">${esc(c.intro)}</p>` : ''}${inner}</section>`;
  }

  /* The whole reference as one HTML page, to save, print or share. */
  /* only: a chapter id (or a list of them) for just those chapters, like the script on one page for a newcomer. */
  function exportHtml(only) {
    const want = only == null ? null : [].concat(only);
    const list = chapters().filter(c => !want || want.includes(c.id));
    const body = list.map(c => chapterHtml(c, '')).join('');
    return `<!doctype html><html><head><meta charset="utf-8"><title>Form Platform reference ${esc(FP.version)}</title><style>
body{font:14px/1.5 system-ui,"Segoe UI",sans-serif;color:#1b2633;max-width:900px;margin:24px auto;padding:0 16px}
h1{font-size:24px}h2{font-size:20px;border-bottom:2px solid #d9dee5;padding-bottom:4px;margin-top:28px}h3{font-size:14px;text-transform:uppercase;letter-spacing:.04em;color:#5b6573}
pre{background:#f4f6f8;border:1px solid #e3e7ec;border-radius:6px;padding:10px;font:12px/1.45 Consolas,monospace}
table{border-collapse:collapse;width:100%}td{border-top:1px solid #eef1f5;padding:4px 8px;vertical-align:top}td:first-child{font-family:Consolas,monospace;white-space:nowrap;color:#1f5fbf;width:1%}
.fph-item{border:1px solid #e3e7ec;border-radius:6px;padding:6px 10px;margin:0 0 6px;break-inside:avoid}.fph-item b{font-family:Consolas,monospace}.fph-item code{display:block;color:#5b21b6;font:12px Consolas,monospace;white-space:pre-wrap}
.fpe-hint{color:#5b6573;font-size:12px}
@media print{body{margin:0;max-width:none;font-size:11px;line-height:1.35}h2{margin-top:10px}pre{font-size:10px;padding:6px}td{padding:2px 6px}}
</style></head><body><h1>${want && list.length === 1 ? esc(list[0].title) : 'Form Platform reference'}</h1><p>Kernel ${esc(FP.version)} · made ${esc(new Date().toLocaleString())} from the platform itself.</p>${body}</body></html>`;
  }

  async function help(host, opts) {
    opts = opts || {};
    injectCss();
    host.replaceChildren();
    const page = el('div', 'fpe');
    host.appendChild(page);
    const head = el('div', 'fpa-head');
    head.style.cssText = 'display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin:0 0 12px';
    const h2 = el('h2', null, 'Help'); h2.style.margin = '0';
    const q = input('', { placeholder: 'Find in the reference: a setting, a function, a keyword…' });
    q.style.flex = '1 1 260px';
    const save = btn('Save as a page', 'small', () => {
      const blob = new Blob([exportHtml()], { type: 'text/html' });
      const a = el('a'); a.href = URL.createObjectURL(blob); a.download = `form-platform-reference-${FP.version}.html`;
      document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    });
    save.title = 'One HTML page with all of it, to print or share';
    const one = btn('Save this chapter', 'small', () => {
      const blob = new Blob([exportHtml(at)], { type: 'text/html' });
      const a = el('a'); a.href = URL.createObjectURL(blob); a.download = `form-platform-${at}-${FP.version}.html`;
      document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    });
    one.title = 'Just the chapter you are on, to print for someone';
    head.append(h2, q, one, save);
    page.appendChild(head);
    const wrap = el('div', 'fph');
    const nav = el('div', 'fph-nav');
    const body = el('div', 'fph-body');
    wrap.append(nav, body);
    page.appendChild(wrap);
    const all = chapters();
    let at = opts.chapter && all.some(c => c.id === opts.chapter) ? opts.chapter : 'script';
    function paint() {
      const query = q.value.trim().toLowerCase();
      nav.replaceChildren(...all.map(c => { const b = btn(c.title, c.id === at && !query ? 'on' : '', () => { at = c.id; q.value = ''; paint(); }); return b; }));
      body.innerHTML = query ? (all.map(c => chapterHtml(c, query)).join('') || '<p class="intro">Nothing matches.</p>') : chapterHtml(all.find(c => c.id === at), '');
      if (opts.onChapter) opts.onChapter(at);
    }
    q.oninput = paint;
    paint();
    return { isDirty: () => false };
  }

  FP.help = { chapters, exportHtml };
  FP.editor.help = help;

  /* Registered last, so a module that failed partway never reports as loaded. */
  (window.FP.modules = window.FP.modules || {})['fp-help'] = '0.44.0';
})();
