#!/bin/bash
# Regression: the kernel unit tests, the chain (parts 1-14 from nothing), then the l-tests from 0.40 on.
cd "$(dirname "$0")"
export TZ=America/Chicago
echo "== unit"; timeout 120 node kt28.js 2>&1 | tail -2
cd dummies
for i in $(seq 0 13); do echo "== chain part $((i+1))"; FROM=$i SNAP=1 timeout 300 node build.js $((i+1)) 2>&1 | grep -i "error\|fail\|timeout\|✗" | head -5; done
cd ..
for t in l42 l43 l44 l51 l54 l56 l57 l58 l59 l60 l61 l62 l63 l64 l64b l65 l66 l67 l68 l69 l70 l71 l72 l73 l74 l75 l76 l77 l78 l79 l80 l81 l82 l83 l84 l85 l86 l87 l88 l89 l90 l91; do echo "== $t"; timeout 300 node $t.js 2>&1 | grep -i "error\|fail\|timeout\|exceeded" | head -5; done
